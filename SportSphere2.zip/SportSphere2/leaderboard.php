<?php
require "config/db.php";
require "auth_check.php";   
require "role_check.php"; 

allowRoles(['organizer','player','spectator']);

$teams = $pdo->query("
SELECT 
 t.id,
 t.name,
 t.points,
 COUNT(m.id) AS played,
 SUM(CASE WHEN m.winner = 1 AND m.team1_id = t.id THEN 1
          WHEN m.winner = 2 AND m.team2_id = t.id THEN 1
          ELSE 0 END) AS wins,
 SUM(CASE WHEN m.winner = 1 AND m.team2_id = t.id THEN 1
          WHEN m.winner = 2 AND m.team1_id = t.id THEN 1
          ELSE 0 END) AS losses,
 SUM(CASE WHEN m.winner = 0 THEN 1 ELSE 0 END) AS draws
FROM teams t
LEFT JOIN matches m 
 ON (t.id = m.team1_id OR t.id = m.team2_id) AND m.played = 1
GROUP BY t.id
ORDER BY t.points DESC
")->fetchAll();
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Leaderboard | SportSphere</title>
<link href="https://fonts.googleapis.com/css2?family=Barlow+Condensed:wght@700;900&family=Barlow:wght@400;500;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="organizer_style.css">
</head>
<body>

<div class="sidebar">
  <h2>🏀 SportSphere</h2>
  <a href="dashboard.php">📊 Dashboard</a>
  <a href="tournaments.php">🏆 Tournaments</a>
  <a href="teams.php">👥 Teams</a>
  <a href="matches.php">📅 Matches</a>
  <a href="players.php">🏀 Players</a>
  <a href="leaderboard.php" class="active">🏅 Leaderboard</a>
  <a href="ads.php">📢 Manage Ads</a>
  <a href="auth/logout.php" style="margin-top:20px; color:var(--red);">🚪 Logout</a>
</div>

<div class="main">

  <div class="page-header">
    <h1>🏅 Global Leaderboard</h1>
  </div>

  <div class="table-card">
    <table>
      <thead>
        <tr>
          <th style="width:60px; text-align:center;">Rank</th>
          <th>Team Name</th>
          <th style="text-align:center;">Played</th>
          <th style="text-align:center;">Won</th>
          <th style="text-align:center;">Drawn</th>
          <th style="text-align:center;">Lost</th>
          <th style="text-align:center;">Total Points</th>
        </tr>
      </thead>
      <tbody>
        <?php $rank = 1; ?>
        <?php foreach($teams as $t): ?>
        <tr>
          <td style="text-align:center; font-family:'Barlow Condensed', sans-serif; font-size:20px; font-weight:900; color:var(--orange);">#<?= $rank++ ?></td>
          <td style="font-weight:600; font-size:16px;"><?= htmlspecialchars($t['name']) ?></td>
          <td style="text-align:center;"><span class="badge" style="background:var(--blue); color:#fff; padding:6px 12px;"><?= $t['played'] ?></span></td>
          <td style="text-align:center;"><span class="badge" style="background:var(--green); color:#fff; padding:6px 12px;"><?= $t['wins'] ?></span></td>
          <td style="text-align:center;"><span class="badge" style="background:var(--muted); color:#fff; padding:6px 12px;"><?= $t['draws'] ?></span></td>
          <td style="text-align:center;"><span class="badge" style="background:var(--red); color:#fff; padding:6px 12px;"><?= $t['losses'] ?></span></td>
          <td style="text-align:center; font-family:'Barlow Condensed', sans-serif; font-size:24px; font-weight:900; color:var(--orange);"><?= $t['points'] ?></td>
        </tr>
        <?php endforeach; ?>
        
        <?php if(count($teams) == 0): ?>
          <tr><td colspan="7" style="text-align:center; padding:30px; color:var(--muted);">No teams registered yet.</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>

  <div style="margin-top:30px;">
    <a href="dashboard.php" class="btn" style="background:#333; color:#fff; padding:10px 20px;">⬅ Back to Dashboard</a>
  </div>

</div>

</body>
</html>