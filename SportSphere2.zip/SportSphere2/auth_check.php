<?php

if(session_status() === PHP_SESSION_NONE){
 session_start();
}
if(!isset($_SESSION['user'])){
 header("Location: auth/login.php");
 exit();
}

$role = $_SESSION['role'] ?? 'player';
$is_paid = $_SESSION['is_paid'] ?? 0;
// Default to future if not set for some extremely old users prior to migration
$trial_ends_at = $_SESSION['trial_ends_at'] ?? '2099-01-01 00:00:00';

if($role !== 'organizer' && $is_paid == 0){
    if(time() > strtotime($trial_ends_at)){
        $current_script = basename($_SERVER['SCRIPT_NAME']);
        if($current_script !== 'payment.php' && $current_script !== 'logout.php'){
            header("Location: payment.php");
            exit();
        }
    }
}
?>