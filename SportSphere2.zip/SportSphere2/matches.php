<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require "config/db.php";
require "auth_check.php";
require "role_check.php";

allowRoles(['organizer']);

/* ===================== SAVE MATCH ===================== */
if(isset($_POST['save_match'])){

 if(empty($_POST['date']) || empty($_POST['time'])){
  echo "<p style='color:red;'>Date and time required</p>";
  exit();
 }

 if($_POST['team1'] == $_POST['team2']){
  echo "<p style='color:red;'>Teams must be different</p>";
  exit();
 }

 $date = $_POST['date'];
 $time = date("H:i:s", strtotime($_POST['time']));

 $pdo->prepare("
 INSERT INTO matches(tournament_id,team1_id,team2_id,match_date,match_time)
 VALUES(?,?,?,?,?)
 ")->execute([
  $_POST['tournament'],
  $_POST['team1'],
  $_POST['team2'],
  $date,
  $time
 ]);

 header("Location: matches.php");
 exit();
}

/* ===================== UPDATE SCORE ===================== */
if(isset($_POST['update_score'])){

 if($_POST['score1'] === "" || $_POST['score2'] === ""){
  echo "<p style='color:red;'>Enter both scores</p>";
  exit();
 }

 $score1 = (int)$_POST['score1'];
 $score2 = (int)$_POST['score2'];

 // DETERMINE WINNER
 if($score1 > $score2){
  $winner = 1;
 } elseif($score2 > $score1){
  $winner = 2;
 } else {
  $winner = 0;
 }

 $pdo->prepare("
 UPDATE matches 
 SET score1=?, score2=?, played=1, winner=? 
 WHERE id=?
 ")->execute([$score1,$score2,$winner,$_POST['match_id']]);

 // RESET POINTS
 $pdo->query("UPDATE teams SET points=0");

 // RECALCULATE LEADERBOARD
 $allMatches = $pdo->query("SELECT * FROM matches WHERE played=1")->fetchAll();
 foreach($allMatches as $m){
  if($m['winner'] == 1){
   $pdo->prepare("UPDATE teams SET points = points + 3 WHERE id=?")
       ->execute([$m['team1_id']]);
  } elseif($m['winner'] == 2){
   $pdo->prepare("UPDATE teams SET points = points + 3 WHERE id=?")
       ->execute([$m['team2_id']]);
  } else {
   $pdo->prepare("UPDATE teams SET points = points + 1 WHERE id=?")
       ->execute([$m['team1_id']]);
   $pdo->prepare("UPDATE teams SET points = points + 1 WHERE id=?")
       ->execute([$m['team2_id']]);
  }
 }

 header("Location: matches.php");
 exit();
}

/* ===================== UPDATE DATE/TIME ===================== */
if(isset($_POST['update_datetime'])){
 $date = $_POST['new_date'];
 $time = date("H:i:s", strtotime($_POST['new_time']));

 $pdo->prepare("
 UPDATE matches 
 SET match_date=?, match_time=? 
 WHERE id=?
 ")->execute([$date,$time,$_POST['match_id']]);

 header("Location: matches.php");
 exit();
}

/* ===================== FETCH DATA ===================== */
$tours = $pdo->query("SELECT * FROM tournaments")->fetchAll();
$teams = $pdo->query("SELECT * FROM teams")->fetchAll();

$matches = $pdo->query("
SELECT m.*, 
t1.name AS team1, 
t2.name AS team2,
tournaments.name AS tname
FROM matches m
JOIN teams t1 ON m.team1_id=t1.id
JOIN teams t2 ON m.team2_id=t2.id
JOIN tournaments ON m.tournament_id=tournaments.id
ORDER BY match_date DESC
")->fetchAll();
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Matches | SportSphere</title>
<link href="https://fonts.googleapis.com/css2?family=Barlow+Condensed:wght@700;900&family=Barlow:wght@400;500;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="organizer_style.css">
</head>
<body>

<div class="sidebar">
  <h2>🏀 SportSphere</h2>
  <a href="dashboard.php">📊 Dashboard</a>
  <a href="tournaments.php">🏆 Tournaments</a>
  <a href="teams.php">👥 Teams</a>
  <a href="matches.php" class="active">📅 Matches</a>
  <a href="players.php">🏀 Players</a>
  <a href="leaderboard.php">🏅 Leaderboard</a>
  <a href="ads.php">📢 Manage Ads</a>
  <a href="auth/logout.php" style="margin-top:20px; color:var(--red);">🚪 Logout</a>
</div>

<div class="main">

  <div class="page-header">
    <h1>📅 Match Schedule</h1>
  </div>

  <form method="POST" class="form-card">
    <div class="grid-2">
      <div>
        <label>Select Tournament</label>
        <select name="tournament" required>
        <?php foreach($tours as $t): ?>
        <option value="<?= $t['id'] ?>"><?= htmlspecialchars($t['name']) ?></option>
        <?php endforeach; ?>
        </select>
      </div>
      <div>
        <label>Team 1 (Home)</label>
        <select name="team1" required>
        <?php foreach($teams as $t): ?>
        <option value="<?= $t['id'] ?>"><?= htmlspecialchars($t['name']) ?></option>
        <?php endforeach; ?>
        </select>
      </div>
      <div>
        <label>Team 2 (Away)</label>
        <select name="team2" required>
        <?php foreach($teams as $t): ?>
        <option value="<?= $t['id'] ?>"><?= htmlspecialchars($t['name']) ?></option>
        <?php endforeach; ?>
        </select>
      </div>
      <div>
        <label>Date & Time</label>
        <div style="display:flex; gap:10px;">
          <input type="date" name="date" value="<?= date('Y-m-d') ?>" required>
          <input type="time" name="time" value="<?= date('H:i') ?>" required>
        </div>
      </div>
    </div>
    <button name="save_match" class="btn" style="margin-top:10px;">+ Schedule Match</button>
  </form>

  <h3 style="font-family:'Barlow Condensed', sans-serif; font-size:24px; color:var(--orange); margin-bottom:15px; margin-top:30px;">Match History</h3>

  <div class="grid-2">
    <?php foreach($matches as $m): ?>
    <div class="card" style="margin-bottom:0px; padding:20px;">
      
      <div style="font-family:'Barlow Condensed', sans-serif; font-size:24px; margin-bottom:8px; display:flex; justify-content:space-between; align-items:center;">
        <div><?= htmlspecialchars($m['team1']) ?> <span style="color:var(--muted); font-size:16px;">vs</span> <?= htmlspecialchars($m['team2']) ?></div>
        <?php if($m['played']): ?>
          <span class="badge badge-active">Completed</span>
        <?php else: ?>
          <span class="badge badge-inactive">Upcoming</span>
        <?php endif; ?>
      </div>

      <div style="font-size:13px; color:var(--muted); font-weight:600; margin-bottom:15px; border-bottom:1px solid var(--border); padding-bottom:15px; display:flex; gap:15px;">
        <span>🏆 <?= htmlspecialchars($m['tname']) ?></span>
        <span>📅 <?= date("M d, Y", strtotime($m['match_date'])) ?></span>
        <span>🕒 <?= date("h:i A", strtotime($m['match_time'])) ?></span>
      </div>

      <div style="display:flex; gap:20px;">
        <!-- UPDATE SCORE -->
        <form method="POST" style="flex:1; background:#111; padding:15px; border-radius:8px; border:1px solid var(--border);">
          <label style="color:var(--orange);">Update Score</label>
          <input type="hidden" name="match_id" value="<?= $m['id'] ?>">
          <div style="display:flex; gap:10px; margin-bottom:10px;">
            <input type="number" name="score1" min="0" placeholder="T1" required style="margin:0;">
            <input type="number" name="score2" min="0" placeholder="T2" required style="margin:0;">
          </div>
          <button name="update_score" class="btn btn-sm" style="width:100%; margin:0;">Save Score</button>
        </form>

        <!-- RESCHEDULE -->
        <form method="POST" style="flex:1; background:#111; padding:15px; border-radius:8px; border:1px solid var(--border);">
          <label style="color:var(--orange);">Reschedule</label>
          <input type="hidden" name="match_id" value="<?= $m['id'] ?>">
          <div style="display:flex; gap:10px; margin-bottom:10px;">
            <input type="date" name="new_date" value="<?= $m['match_date'] ?>" required style="margin:0;">
            <input type="time" name="new_time" value="<?= date('H:i', strtotime($m['match_time'])) ?>" required style="margin:0;">
          </div>
          <button name="update_datetime" class="btn btn-sm" style="width:100%; margin:0;">Save Schedule</button>
        </form>
      </div>

      <div style="margin-top:15px;">
        <a href="match_details.php?id=<?= $m['id'] ?>" class="btn btn-sm" style="width:100%; text-align:center; background:transparent; border:1px solid var(--border); color:#fff; transition:0.3s;" onmouseover="this.style.background='#222';" onmouseout="this.style.background='transparent';">View Full Output & Details</a>
      </div>

    </div>
    <?php endforeach; ?>
  </div>

  <div style="margin-top:30px;">
    <a href="dashboard.php" class="btn" style="background:#333; color:#fff; padding:10px 20px;">⬅ Back to Dashboard</a>
  </div>

</div>

</body>
</html>