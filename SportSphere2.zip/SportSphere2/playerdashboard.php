<?php
require "config/db.php";
require "auth_check.php";
require "role_check.php";

allowRoles(['player']);

// Fetch Active Ads
try {
    $active_ads = $pdo->query("SELECT ad_text FROM ads WHERE is_active = 1")->fetchAll(PDO::FETCH_COLUMN);
} catch (PDOException $e) {
    $active_ads = []; // Failsafe if table doesn't exist
}

// ── Safe session key resolution ─────────────────────────────────────────────
//$userId = $_SESSION['user_id'] ?? $_SESSION['id'] ?? $_SESSION['uid'] ?? null;
$userId = $_SESSION['user'] ?? null;
if (!$userId) { header("Location: auth/login.php"); exit; }

// ── Fetch logged-in user ─────────────────────────────────────────────────────
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$userId]);
$player = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$player) { header("Location: auth/login.php"); exit; }

// ── Auto-Link Player ──────────────────────────────────────────────────────────
// If the Organizer added this player by name, but their user_id is missing, auto-link it!
$pdo->prepare("UPDATE players SET user_id = ? WHERE name = ? AND (user_id IS NULL OR user_id = 0)")
    ->execute([$userId, $player['name']]);

// ── Fetch player record (links user → team → tournament) ────────────────────
$stmtP = $pdo->prepare("
    SELECT p.*, t.name AS team_name, t.tournament_id, t.points AS team_points
    FROM players p
    LEFT JOIN teams t ON p.team_id = t.id
    WHERE p.user_id = ?
");
$stmtP->execute([$userId]);
$playerRecord = $stmtP->fetch(PDO::FETCH_ASSOC);

$myTeamId       = $playerRecord['team_id']       ?? null;
$myTournamentId = $playerRecord['tournament_id'] ?? null;
$myTeamName     = $playerRecord['team_name']     ?? null;
$myTeamPoints   = $playerRecord['team_points']   ?? 0;

// ── Fetch my tournament info ─────────────────────────────────────────────────
$myTournament = null;
if ($myTournamentId) {
    $stmtT = $pdo->prepare("SELECT * FROM tournaments WHERE id = ?");
    $stmtT->execute([$myTournamentId]);
    $myTournament = $stmtT->fetch(PDO::FETCH_ASSOC);
}

// ── All tournaments ──────────────────────────────────────────────────────────
$allTournaments = $pdo->query("
    SELECT t.*, COUNT(DISTINCT tm.id) AS team_count
    FROM tournaments t
    LEFT JOIN teams tm ON tm.tournament_id = t.id
    GROUP BY t.id
    ORDER BY t.start_date DESC
")->fetchAll(PDO::FETCH_ASSOC);

// ── All matches ──────────────────────────────────────────────────────────────
$allMatches = $pdo->query("
    SELECT m.*,
           t1.name AS team1_name, t2.name AS team2_name,
           tr.name AS tournament_name, tr.match_type
    FROM matches m
    JOIN teams t1  ON m.team1_id      = t1.id
    JOIN teams t2  ON m.team2_id      = t2.id
    JOIN tournaments tr ON m.tournament_id = tr.id
    ORDER BY m.match_date DESC, m.match_time DESC
")->fetchAll(PDO::FETCH_ASSOC);

$previousMatches = array_values(array_filter($allMatches, fn($m) => $m['played']));
$upcomingMatches = array_values(array_filter($allMatches, fn($m) => !$m['played']));

// ── My team's matches & record ───────────────────────────────────────────────
$myMatches = $myTeamId
    ? array_values(array_filter($allMatches, fn($m) => $m['team1_id']==$myTeamId || $m['team2_id']==$myTeamId))
    : [];
$myMatchesWon = $myMatchesLost = $myMatchesDraw = 0;
foreach ($myMatches as $m) {
    if (!$m['played']) continue;
    if ($m['winner']==0)                                                                     $myMatchesDraw++;
    elseif (($m['winner']==1&&$m['team1_id']==$myTeamId)||($m['winner']==2&&$m['team2_id']==$myTeamId)) $myMatchesWon++;
    else                                                                                     $myMatchesLost++;
}

// ── Teammates ────────────────────────────────────────────────────────────────
$teammates = [];
if ($myTeamId) {
    $stmtTM = $pdo->prepare("
        SELECT p.*, u.name AS user_name, u.position, u.skill
        FROM players p
        LEFT JOIN users u ON p.user_id = u.id
        WHERE p.team_id = ? AND p.user_id != ?
    ");
    $stmtTM->execute([$myTeamId, $userId]);
    $teammates = $stmtTM->fetchAll(PDO::FETCH_ASSOC);
}

// ── Standings for my tournament ──────────────────────────────────────────────
$standings = [];
if ($myTournamentId) {
    $stmtSt = $pdo->prepare("
        SELECT t.name, t.points,
               SUM(CASE WHEN (m.team1_id=t.id OR m.team2_id=t.id) AND m.played=1 THEN 1 ELSE 0 END) AS played,
               SUM(CASE WHEN ((m.winner=1 AND m.team1_id=t.id) OR (m.winner=2 AND m.team2_id=t.id)) THEN 1 ELSE 0 END) AS wins,
               SUM(CASE WHEN m.played=1 AND m.winner=0 AND (m.team1_id=t.id OR m.team2_id=t.id) THEN 1 ELSE 0 END) AS draws,
               SUM(CASE WHEN ((m.winner=1 AND m.team2_id=t.id) OR (m.winner=2 AND m.team1_id=t.id)) THEN 1 ELSE 0 END) AS losses
        FROM teams t
        LEFT JOIN matches m ON (m.team1_id=t.id OR m.team2_id=t.id)
        WHERE t.tournament_id = ?
        GROUP BY t.id
        ORDER BY t.points DESC
    ");
    $stmtSt->execute([$myTournamentId]);
    $standings = $stmtSt->fetchAll(PDO::FETCH_ASSOC);
}

// ── Handle profile update ────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['update_profile'])) {
    $upd = $pdo->prepare("UPDATE users SET name=?,email=?,phone=?,dob=?,position=?,address=? WHERE id=?");
    $upd->execute([
        trim($_POST['name']), trim($_POST['email']), trim($_POST['phone']),
        trim($_POST['dob']) ?: null, trim($_POST['position']), trim($_POST['address']),
        $userId
    ]);
    header("Location: playerdashboard.php?tab=account&updated=1"); exit;
}

// ── Handle password change ───────────────────────────────────────────────────
$pwError = $pwSuccess = '';
if ($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['change_password'])) {
    $current = $_POST['current_password'];
    $new     = $_POST['new_password'];
    $confirm = $_POST['confirm_password'];
    if (!password_verify($current, $player['password']))    $pwError = 'Current password is incorrect.';
    elseif (strlen($new) < 6)                               $pwError = 'New password must be at least 6 characters.';
    elseif ($new !== $confirm)                              $pwError = 'Passwords do not match.';
    else {
        $pdo->prepare("UPDATE users SET password=? WHERE id=?")->execute([password_hash($new,PASSWORD_DEFAULT),$userId]);
        $pwSuccess = 'Password updated successfully!';
        // re-fetch
        $stmt->execute([$userId]); $player = $stmt->fetch(PDO::FETCH_ASSOC);
    }
}

// ── Active tab & watch match ─────────────────────────────────────────────────
$tab = $_GET['tab'] ?? 'home';
$selectedId = isset($_GET['match_id']) ? (int)$_GET['match_id'] : null;
$watchMatch = null;
if ($selectedId) { foreach ($allMatches as $m) { if ($m['id']==$selectedId){$watchMatch=$m;break;} } }
if (!$watchMatch && count($allMatches)) $watchMatch = $allMatches[0];

$initials = strtoupper(substr($player['name']??'P',0,2));
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>SportSphere — Player Dashboard</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=DM+Sans:wght@400;500;600;700&family=JetBrains+Mono:wght@400;700&display=swap" rel="stylesheet">
<style>
/* ══ RESET ══ */
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0;}
:root{
  --bg:#080C10; --s1:#0E1318; --s2:#141B22; --s3:#1C2530;
  --bd:rgba(255,255,255,0.06); --bd2:rgba(255,255,255,0.11);
  --or:#FF5C1A; --or2:#FF8C4A; --bl:#1AABFF;
  --gr:#00E87A; --rd:#FF3B5C; --yw:#FFD020; --pu:#A855F7;
  --tx:#EEF2F6; --mu:#4A5568; --mu2:#8899AA;
  --sw:72px; --hh:60px;
  --fh:'Bebas Neue',sans-serif; --fb:'DM Sans',sans-serif; --fm:'JetBrains Mono',monospace;
}
html,body{height:100%;overflow:hidden;}
body{font-family:var(--fb);background:var(--bg);color:var(--tx);display:flex;}
::-webkit-scrollbar{width:4px;} ::-webkit-scrollbar-thumb{background:var(--bd2);border-radius:2px;}

/* ══ SIDEBAR ══ */
.sb{width:var(--sw);background:var(--s1);border-right:1px solid var(--bd);display:flex;flex-direction:column;align-items:center;padding:14px 0;gap:2px;position:fixed;top:0;left:0;height:100vh;z-index:200;}
.sb-logo{width:38px;height:38px;border-radius:9px;background:var(--or);display:flex;align-items:center;justify-content:center;font-family:var(--fh);font-size:17px;color:#fff;margin-bottom:14px;}
.ni{width:46px;height:46px;border-radius:10px;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:3px;cursor:pointer;color:var(--mu);text-decoration:none;transition:background .15s,color .15s;}
.ni svg{width:19px;height:19px;} .ni .nl{font-size:7.5px;font-weight:700;letter-spacing:.05em;text-transform:uppercase;}
.ni:hover{background:var(--s2);color:var(--tx);} .ni.on{background:var(--or);color:#fff;}
.sb-gap{flex:1;}
.sb-av{width:34px;height:34px;border-radius:50%;background:linear-gradient(135deg,var(--or),var(--bl));display:flex;align-items:center;justify-content:center;font-weight:800;font-size:13px;color:#fff;margin-bottom:4px;}

/* ══ LAYOUT ══ */
.app{margin-left:var(--sw);flex:1;display:flex;flex-direction:column;height:100vh;overflow:hidden;}
.topbar{height:var(--hh);background:var(--s1);border-bottom:1px solid var(--bd);display:flex;align-items:center;padding:0 22px;gap:12px;flex-shrink:0;}
.tb-ttl{font-family:var(--fh);font-size:23px;letter-spacing:.04em;flex:1;} .tb-ttl span{color:var(--or);}
.pill{display:flex;align-items:center;gap:7px;background:var(--s2);border:1px solid var(--bd2);padding:5px 13px;border-radius:99px;font-size:12px;color:var(--mu2);}
.dot{width:7px;height:7px;border-radius:50%;background:var(--gr);box-shadow:0 0 5px var(--gr);animation:blink 2s infinite;}
@keyframes blink{0%,100%{opacity:1}50%{opacity:.25}}
.page{flex:1;overflow-y:auto;padding:22px;}

/* ══ BUTTONS ══ */
.btn{display:inline-flex;align-items:center;justify-content:center;gap:7px;padding:9px 18px;border-radius:8px;font-family:var(--fb);font-size:13px;font-weight:700;cursor:pointer;border:none;text-decoration:none;transition:all .15s;}
.btn-p{background:var(--or);color:#fff;} .btn-p:hover{background:var(--or2);}
.btn-g{background:transparent;border:1px solid var(--bd2);color:var(--mu2);} .btn-g:hover{border-color:var(--or);color:var(--or);}
.btn-d{background:rgba(255,59,92,.12);border:1px solid rgba(255,59,92,.3);color:var(--rd);}
.btn-sm{padding:5px 12px;font-size:12px;} .btn-bl{width:100%;}

/* ══ GRID / CARD ══ */
.g2{display:grid;grid-template-columns:1fr 1fr;gap:18px;}
.g3{display:grid;grid-template-columns:1fr 1fr 1fr;gap:18px;}
.g4{display:grid;grid-template-columns:repeat(4,1fr);gap:18px;}
.g5{display:grid;grid-template-columns:repeat(5,1fr);gap:18px;}
.card{background:var(--s1);border:1px solid var(--bd);border-radius:14px;padding:20px;}
.ch{display:flex;align-items:center;justify-content:space-between;margin-bottom:15px;}
.ct{font-family:var(--fh);font-size:18px;letter-spacing:.05em;}

/* ══ STAT CARD ══ */
.sc{background:var(--s1);border:1px solid var(--bd);border-radius:14px;padding:18px;position:relative;overflow:hidden;}
.sc::before{content:'';position:absolute;top:0;left:0;right:0;height:3px;background:var(--c,var(--or));}
.sc-icon{font-size:23px;margin-bottom:8px;} .sc-val{font-family:var(--fh);font-size:34px;line-height:1;letter-spacing:.02em;}
.sc-lbl{font-size:10px;color:var(--mu2);text-transform:uppercase;letter-spacing:.07em;margin-top:4px;font-weight:700;}
.sc-sub{font-size:12px;color:var(--mu2);margin-top:6px;} .sc-sub.up{color:var(--gr);font-weight:700;} .sc-sub.dn{color:var(--rd);font-weight:700;}

/* ══ TAGS ══ */
.tag{display:inline-flex;align-items:center;gap:4px;font-size:11px;font-weight:800;letter-spacing:.05em;text-transform:uppercase;padding:3px 9px;border-radius:99px;}
.tl{background:rgba(255,92,26,.15);color:var(--or);border:1px solid rgba(255,92,26,.3);}
.td{background:rgba(0,232,122,.12);color:var(--gr);border:1px solid rgba(0,232,122,.25);}
.ts{background:rgba(26,171,255,.12);color:var(--bl);border:1px solid rgba(26,171,255,.25);}
.ty{background:rgba(255,208,32,.12);color:var(--yw);border:1px solid rgba(255,208,32,.25);}
.tp{background:rgba(168,85,247,.12);color:var(--pu);border:1px solid rgba(168,85,247,.25);}
.tdot{width:5px;height:5px;border-radius:50%;background:currentColor;}

/* ══ TABLE ══ */
.tbl{width:100%;border-collapse:collapse;}
.tbl th{font-size:11px;text-transform:uppercase;letter-spacing:.08em;color:var(--mu);font-weight:700;padding:9px 12px;border-bottom:1px solid var(--bd);text-align:left;}
.tbl td{padding:11px 12px;border-bottom:1px solid var(--bd);font-size:13px;vertical-align:middle;}
.tbl tr:last-child td{border-bottom:none;} .tbl tbody tr:hover td{background:rgba(255,255,255,.02);}
.my-row td{background:rgba(255,92,26,.05)!important;} .my-row td:first-child{border-left:3px solid var(--or);}

/* ══ SCOREBOARD ══ */
.sboard{background:linear-gradient(135deg,var(--s1),var(--s2));border:1px solid var(--bd2);border-radius:16px;padding:24px 30px;display:flex;align-items:center;justify-content:space-between;gap:16px;position:relative;overflow:hidden;margin-bottom:18px;}
.sboard::after{content:'';position:absolute;inset:0;background:radial-gradient(ellipse at 50% 0%,rgba(255,92,26,.07) 0%,transparent 65%);pointer-events:none;}
.sb-team{display:flex;flex-direction:column;align-items:center;gap:6px;flex:1;}
.sb-badge{width:48px;height:48px;border-radius:50%;background:var(--s3);border:2px solid var(--bd2);display:flex;align-items:center;justify-content:center;font-size:20px;}
.sb-name{font-family:var(--fh);font-size:18px;letter-spacing:.05em;text-align:center;}
.sb-score{font-family:var(--fh);font-size:50px;color:var(--or);line-height:1;}
.sb-mid{display:flex;flex-direction:column;align-items:center;gap:8px;}
.sb-vs{font-family:var(--fh);font-size:24px;color:var(--mu);letter-spacing:.1em;}
.sb-lv{font-family:var(--fm);font-size:12px;color:var(--or);background:rgba(255,92,26,.12);border:1px solid rgba(255,92,26,.25);padding:3px 10px;border-radius:99px;}

/* ══ VIDEO ══ */
.vid{position:relative;border-radius:14px;overflow:hidden;background:#000;aspect-ratio:16/9;margin-bottom:16px;}
.vid iframe{width:100%;height:100%;border:none;display:block;}
.vid-lbl{position:absolute;top:12px;left:12px;background:var(--or);color:#fff;font-size:10px;font-weight:800;letter-spacing:.08em;text-transform:uppercase;padding:3px 9px;border-radius:5px;}

/* ══ FORMS ══ */
.fg{margin-bottom:15px;} .fl{display:block;font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.06em;color:var(--mu2);margin-bottom:5px;}
.fi,.fsel,.fta{width:100%;background:var(--s2);border:1px solid var(--bd2);border-radius:8px;padding:10px 13px;font-family:var(--fb);font-size:14px;color:var(--tx);outline:none;transition:border-color .15s;appearance:none;}
.fi:focus,.fsel:focus,.fta:focus{border-color:var(--or);} .fta{resize:vertical;min-height:80px;}
.frow{display:grid;grid-template-columns:1fr 1fr;gap:16px;}

/* ══ ALERTS ══ */
.alert{border-radius:8px;padding:11px 15px;font-size:13px;font-weight:600;margin-bottom:16px;display:flex;align-items:center;gap:8px;}
.a-ok{background:rgba(0,232,122,.1);border:1px solid rgba(0,232,122,.25);color:var(--gr);}
.a-er{background:rgba(255,59,92,.1);border:1px solid rgba(255,59,92,.25);color:var(--rd);}

/* ══ PROFILE HERO ══ */
.phero{background:linear-gradient(135deg,var(--s1),var(--s2));border:1px solid var(--bd2);border-radius:16px;padding:26px;display:flex;align-items:center;gap:22px;margin-bottom:20px;position:relative;overflow:hidden;}
.phero::before{content:'';position:absolute;top:-50px;right:-50px;width:190px;height:190px;border-radius:50%;background:radial-gradient(circle,rgba(255,92,26,.1),transparent 70%);}
.av-xl{width:74px;height:74px;border-radius:50%;background:linear-gradient(135deg,var(--or),var(--bl));display:flex;align-items:center;justify-content:center;font-family:var(--fh);font-size:29px;color:#fff;flex-shrink:0;border:3px solid rgba(255,255,255,.1);}
.ph-nm{font-family:var(--fh);font-size:32px;letter-spacing:.04em;}
.ph-rl{display:inline-block;font-size:11px;font-weight:800;text-transform:uppercase;letter-spacing:.08em;background:rgba(255,92,26,.15);color:var(--or);border:1px solid rgba(255,92,26,.3);padding:2px 10px;border-radius:99px;margin-top:4px;}
.ph-mt{font-size:13px;color:var(--mu2);margin-top:7px;line-height:1.8;}

/* ══ MATCH PICKER ══ */
.ml{display:flex;flex-direction:column;gap:7px;}
.mi{background:var(--s2);border:1px solid var(--bd);border-radius:9px;padding:11px 13px;cursor:pointer;transition:border-color .15s;text-decoration:none;color:inherit;display:block;}
.mi:hover{border-color:var(--or);} .mi.on{border-color:var(--or);background:rgba(255,92,26,.07);}
.mi-t{font-size:13px;font-weight:600;margin-bottom:3px;} .mi-m{font-size:11px;color:var(--mu2);}

/* ══ SKILL BAR ══ */
.sk-bar{height:5px;background:var(--s3);border-radius:3px;overflow:hidden;margin-top:4px;}
.sk-fill{height:100%;border-radius:3px;background:linear-gradient(90deg,var(--or),var(--or2));transition:width .6s;}

/* ══ EMPTY STATE ══ */
.empty{text-align:center;padding:44px 20px;}
.ei{font-size:42px;margin-bottom:10px;} .et{font-family:var(--fh);font-size:20px;margin-bottom:6px;} .es{font-size:13px;color:var(--mu2);}

/* ══ RESPONSIVE ══ */
@media(max-width:960px){.g4,.g5{grid-template-columns:1fr 1fr;}.g3{grid-template-columns:1fr 1fr;}}
@media(max-width:640px){.g2,.g3,.g4,.g5{grid-template-columns:1fr;}.frow{grid-template-columns:1fr;}.page{padding:14px;}}
</style>
</head>
<body>

<!-- ██ SIDEBAR ██ -->
<nav class="sb">
  <div class="sb-logo">SS</div>
  <?php
  $nav=[
    ['home',    'Home',    '<path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/>'],
    ['live',    'Live',    '<circle cx="12" cy="12" r="10"/><polygon points="10 8 16 12 10 16 10 8"/>'],
    ['scores',  'Scores',  '<line x1="12" y1="20" x2="12" y2="10"/><line x1="18" y1="20" x2="18" y2="4"/><line x1="6" y1="20" x2="6" y2="16"/>'],
    ['history', 'History', '<polyline points="12 8 12 12 14 14"/><circle cx="12" cy="12" r="10"/>'],
    ['team',    'Team',    '<path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 00-3-3.87"/><path d="M16 3.13a4 4 0 010 7.75"/>'],
    ['standings','Ranks',  '<polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/>'],
    ['account', 'Me',      '<path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/><circle cx="12" cy="7" r="4"/>'],
  ];
  foreach($nav as [$t,$l,$d]):
    $a=$tab===$t?'on':'';
  ?>
  <a href="?tab=<?=$t?>" class="ni <?=$a?>" title="<?=$l?>">
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><?=$d?></svg>
    <span class="nl"><?=$l?></span>
  </a>
  <?php endforeach; ?>
  <div class="sb-gap"></div>
  <div class="sb-av"><?=$initials?></div>
  <a href="auth/logout.php" class="ni" title="Logout" style="color:var(--rd);">
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/>
    </svg>
    <span class="nl">Exit</span>
  </a>
</nav>

<!-- ██ APP ██ -->
<div class="app">

<?php if(count($active_ads) > 0): ?>
<div style="background:#0a0a0a; border-bottom:1px solid var(--bd); padding:12px 0; color:#fff; display:flex; align-items:center;">
  <marquee behavior="scroll" direction="left" scrollamount="6" style="flex:1;">
    <?php foreach($active_ads as $ad): ?>
      <span style="color:var(--or); font-weight:700; margin-right:80px; font-size:16px;">
        <?= htmlspecialchars($ad) ?>
      </span>
    <?php endforeach; ?>
  </marquee>
  <a href="mailto:admin@sportsphere.com?subject=Advertisement%20Inquiry" style="min-width:200px; padding:0 20px; color:var(--mu2); font-size:12px; text-transform:uppercase; letter-spacing:1px; text-decoration:none; display:flex; align-items:center; gap:8px; border-left:1px solid var(--bd);">
    <span>📢 Advertise With Us</span>
  </a>
</div>
<?php endif; ?>
<header class="topbar">
  <div class="tb-ttl">
  <?php $ttls=['home'=>'🏠 <span>Overview</span>','live'=>'📡 <span>Live</span> Watch','scores'=>'📊 Live <span>Scores</span>','history'=>'🗂 Match <span>History</span>','team'=>'👥 My <span>Team</span>','standings'=>'🏅 <span>Standings</span>','account'=>'👤 My <span>Account</span>'];
  echo $ttls[$tab]??'Dashboard'; ?>
  </div>
  <?php if(count($upcomingMatches)):?><div class="pill"><span class="dot"></span><?=count($upcomingMatches)?> Upcoming</div><?php endif;?>
  <?php if($myTeamName):?><div class="pill" style="color:var(--or);border-color:rgba(255,92,26,.25);">⚽ <?=htmlspecialchars($myTeamName)?></div><?php endif;?>
  <a href="auth/logout.php" class="btn btn-g btn-sm">Logout</a>
</header>

<main class="page">

<?php /* ══════ HOME ══════ */ if($tab==='home'): ?>

<!-- Welcome Banner -->
<div style="background:linear-gradient(135deg,var(--s1),var(--s2));border:1px solid var(--bd2);border-radius:16px;padding:24px 28px;margin-bottom:20px;position:relative;overflow:hidden;">
  <div style="position:absolute;right:-30px;top:-30px;width:170px;height:170px;border-radius:50%;background:radial-gradient(circle,rgba(255,92,26,.12),transparent 70%);"></div>
  <div style="font-size:10px;text-transform:uppercase;letter-spacing:.1em;color:var(--mu2);margin-bottom:5px;">Welcome back, athlete</div>
  <div style="font-family:var(--fh);font-size:34px;letter-spacing:.04em;line-height:1;"><?=htmlspecialchars($player['name'])?></div>
  <div style="font-size:13px;color:var(--mu2);margin-top:8px;display:flex;gap:16px;flex-wrap:wrap;">
    <?php if($myTeamName):?><span>⚽ <strong style="color:var(--tx);"><?=htmlspecialchars($myTeamName)?></strong></span><?php endif;?>
    <?php if($myTournament):?><span>🏆 <strong style="color:var(--tx);"><?=htmlspecialchars($myTournament['name'])?></strong></span><?php endif;?>
    <?php if($player['position']):?><span>🎯 <strong style="color:var(--tx);"><?=htmlspecialchars($player['position'])?></strong></span><?php endif;?>
    <span>⭐ <strong style="color:var(--tx);"><?=ucfirst($player['subscription'])?></strong></span>
  </div>
</div>

<!-- Stats -->
<div class="g5" style="margin-bottom:20px;">
  <div class="sc" style="--c:var(--or);"><div class="sc-icon">🏟</div><div class="sc-val"><?=count($allMatches)?></div><div class="sc-lbl">Total Matches</div><div class="sc-sub">Season</div></div>
  <div class="sc" style="--c:var(--gr);"><div class="sc-icon">✅</div><div class="sc-val"><?=$myMatchesWon?></div><div class="sc-lbl">Wins</div><div class="sc-sub up">My team</div></div>
  <div class="sc" style="--c:var(--rd);"><div class="sc-icon">❌</div><div class="sc-val"><?=$myMatchesLost?></div><div class="sc-lbl">Losses</div><div class="sc-sub dn">My team</div></div>
  <div class="sc" style="--c:var(--yw);"><div class="sc-icon">🤝</div><div class="sc-val"><?=$myMatchesDraw?></div><div class="sc-lbl">Draws</div><div class="sc-sub">My team</div></div>
  <div class="sc" style="--c:var(--bl);"><div class="sc-icon">🏅</div><div class="sc-val"><?=$myTeamPoints?></div><div class="sc-lbl">Team Pts</div><div class="sc-sub up"><?=$myTeamName?htmlspecialchars($myTeamName):'—'?></div></div>
</div>

<div class="g2">
  <!-- Upcoming -->
  <div class="card">
    <div class="ch"><div class="ct">Upcoming Matches</div><a href="?tab=scores" class="btn btn-g btn-sm">View All</a></div>
    <?php $u5=array_slice($upcomingMatches,0,5); if($u5):?>
    <table class="tbl">
      <thead><tr><th>Match</th><th>Tournament</th><th>Date</th></tr></thead>
      <tbody>
        <?php foreach($u5 as $m): $isMy=($m['team1_id']==$myTeamId||$m['team2_id']==$myTeamId); ?>
        <tr <?=$isMy?'class="my-row"':''?>>
          <td><div style="font-weight:600;"><?=htmlspecialchars($m['team1_name'])?> <span style="color:var(--mu)">vs</span> <?=htmlspecialchars($m['team2_name'])?><?php if($isMy):?> <span class="tag tl" style="font-size:9px;padding:1px 6px;">MY TEAM</span><?php endif;?></div></td>
          <td style="font-size:12px;color:var(--mu2);"><?=htmlspecialchars($m['tournament_name'])?></td>
          <td style="font-size:12px;"><?=$m['match_date']?></td>
        </tr>
        <?php endforeach;?>
      </tbody>
    </table>
    <?php else:?><div class="empty"><div class="ei">📅</div><div class="es">No upcoming matches</div></div><?php endif;?>
  </div>
  <!-- Recent Results -->
  <div class="card">
    <div class="ch"><div class="ct">Recent Results</div><a href="?tab=history" class="btn btn-g btn-sm">Full History</a></div>
    <?php $r5=array_slice($previousMatches,0,5); if($r5):?>
    <table class="tbl">
      <thead><tr><th>Match</th><th>Score</th><th>Winner</th></tr></thead>
      <tbody>
        <?php foreach($r5 as $m):
          $w=$m['winner']==1?$m['team1_name']:($m['winner']==2?$m['team2_name']:'Draw');
          $isMy=($m['team1_id']==$myTeamId||$m['team2_id']==$myTeamId);
        ?>
        <tr <?=$isMy?'class="my-row"':''?>>
          <td><div style="font-weight:600;font-size:13px;"><?=htmlspecialchars($m['team1_name'])?> <span style="color:var(--mu)">vs</span> <?=htmlspecialchars($m['team2_name'])?></div><?php if($isMy):?><div style="font-size:10px;color:var(--or);font-weight:700;">▸ MY TEAM</div><?php endif;?></td>
          <td style="font-family:var(--fm);font-weight:700;font-size:15px;color:var(--or);"><?=$m['score1']?>–<?=$m['score2']?></td>
          <td style="font-size:13px;color:var(--gr);font-weight:600;"><?=htmlspecialchars($w)?></td>
        </tr>
        <?php endforeach;?>
      </tbody>
    </table>
    <?php else:?><div class="empty"><div class="ei">📭</div><div class="es">No results yet</div></div><?php endif;?>
  </div>
</div>

<?php /* ══════ LIVE ══════ */ elseif($tab==='live'): ?>
<div style="display:flex;gap:18px;align-items:flex-start;">
  <!-- Picker -->
  <div style="width:230px;flex-shrink:0;">
    <div style="font-size:10px;text-transform:uppercase;letter-spacing:.08em;color:var(--mu);margin-bottom:10px;font-weight:700;">Select Match</div>
    <div class="ml">
      <?php foreach($allMatches as $m): $act=$watchMatch&&$m['id']==$watchMatch['id']; ?>
      <a href="?tab=live&match_id=<?=$m['id']?>" class="mi <?=$act?'on':''?>">
        <div class="mi-t"><?=htmlspecialchars($m['team1_name'])?> vs <?=htmlspecialchars($m['team2_name'])?></div>
        <div class="mi-m"><?=htmlspecialchars($m['tournament_name'])?> · <span class="tag <?=$m['played']?'td':'tl'?>" style="font-size:9px;padding:1px 6px;"><?=$m['played']?'Done':'Live'?></span></div>
      </a>
      <?php endforeach;?>
    </div>
  </div>
  <!-- Viewer -->
  <div style="flex:1;min-width:0;">
    <?php if($watchMatch):?>
    <div class="sboard">
      <div class="sb-team"><div class="sb-badge">🏀</div><div class="sb-name"><?=htmlspecialchars($watchMatch['team1_name'])?></div><div class="sb-score"><?=$watchMatch['score1']??0?></div></div>
      <div class="sb-mid">
        <div class="sb-vs">VS</div>
        <?php if(!$watchMatch['played']):?><div class="sb-lv">● LIVE</div><?php else:?><div class="sb-lv" style="color:var(--gr);background:rgba(0,232,122,.1);border-color:rgba(0,232,122,.2);">FINAL</div><?php endif;?>
        <div style="font-size:11px;color:var(--mu2);"><?=$watchMatch['match_date']?> · <?=date('h:i A',strtotime($watchMatch['match_time']))?></div>
      </div>
      <div class="sb-team"><div class="sb-badge">🏀</div><div class="sb-name"><?=htmlspecialchars($watchMatch['team2_name'])?></div><div class="sb-score"><?=$watchMatch['score2']??0?></div></div>
    </div>
    <div class="vid"><div class="vid-lbl">📡 Live Stream</div><iframe src="https://www.youtube.com/embed/a0P4WeUURks" allowfullscreen></iframe></div>
    <div class="card">
      <div class="ch"><div class="ct">Match Details</div><span class="tag <?=$watchMatch['played']?'td':'tl'?>"><?=$watchMatch['played']?'Finished':'Live'?></span></div>
      <div class="g2">
        <?php $dets=[['Tournament',htmlspecialchars($watchMatch['tournament_name'])],['Type',ucfirst($watchMatch['match_type']??'—')],['Date',$watchMatch['match_date']],['Time',date('h:i A',strtotime($watchMatch['match_time']))],['Score',$watchMatch['played']?'<span style="font-family:var(--fm);font-size:18px;color:var(--or);">'.$watchMatch['score1'].' – '.$watchMatch['score2'].'</span>':'—'],['Winner',$watchMatch['played']?($watchMatch['winner']==1?htmlspecialchars($watchMatch['team1_name']):($watchMatch['winner']==2?htmlspecialchars($watchMatch['team2_name']):'Draw')):'—']];
        foreach($dets as[$k,$v]):?>
        <div><div style="font-size:11px;color:var(--mu);text-transform:uppercase;letter-spacing:.06em;margin-bottom:3px;"><?=$k?></div><div style="font-weight:600;"><?=$v?></div></div>
        <?php endforeach;?>
      </div>
    </div>
    <?php endif;?>
  </div>
</div>

<?php /* ══════ SCORES ══════ */ elseif($tab==='scores'): ?>
<?php if($upcomingMatches):?>
<div class="card" style="margin-bottom:18px;">
  <div class="ch"><div class="ct">Upcoming Matches</div><span class="tag ts"><?=count($upcomingMatches)?> Scheduled</span></div>
  <table class="tbl">
    <thead><tr><th>Teams</th><th>Tournament</th><th>Type</th><th>Date</th><th>Time</th><th></th></tr></thead>
    <tbody>
      <?php foreach($upcomingMatches as $m): $isMy=($m['team1_id']==$myTeamId||$m['team2_id']==$myTeamId);?>
      <tr <?=$isMy?'class="my-row"':''?>>
        <td><strong><?=htmlspecialchars($m['team1_name'])?></strong><span style="color:var(--mu);margin:0 6px;">vs</span><strong><?=htmlspecialchars($m['team2_name'])?></strong><?php if($isMy):?><span class="tag tl" style="margin-left:7px;font-size:9px;">MY TEAM</span><?php endif;?></td>
        <td style="color:var(--mu2);font-size:12px;"><?=htmlspecialchars($m['tournament_name'])?></td>
        <td><span class="tag tp"><?=ucfirst($m['match_type']??'—')?></span></td>
        <td style="font-size:13px;"><?=$m['match_date']?></td>
        <td style="font-family:var(--fm);font-size:12px;"><?=date('h:i A',strtotime($m['match_time']))?></td>
        <td><a href="?tab=live&match_id=<?=$m['id']?>" class="btn btn-g btn-sm">Watch</a></td>
      </tr>
      <?php endforeach;?>
    </tbody>
  </table>
</div>
<?php endif;?>
<?php if($previousMatches):?>
<div class="card">
  <div class="ch"><div class="ct">Final Scores</div><span class="tag td"><?=count($previousMatches)?> Completed</span></div>
  <table class="tbl">
    <thead><tr><th>Match</th><th>Tournament</th><th>Score</th><th>Winner</th><th>Date</th></tr></thead>
    <tbody>
      <?php foreach($previousMatches as $m):
        $w=$m['winner']==1?$m['team1_name']:($m['winner']==2?$m['team2_name']:'Draw');
        $isMy=($m['team1_id']==$myTeamId||$m['team2_id']==$myTeamId);
      ?>
      <tr <?=$isMy?'class="my-row"':''?>>
        <td><strong><?=htmlspecialchars($m['team1_name'])?></strong><span style="color:var(--mu);margin:0 6px;">vs</span><strong><?=htmlspecialchars($m['team2_name'])?></strong><?php if($isMy):?><span class="tag tl" style="margin-left:7px;font-size:9px;">MY TEAM</span><?php endif;?></td>
        <td style="color:var(--mu2);font-size:12px;"><?=htmlspecialchars($m['tournament_name'])?></td>
        <td style="font-family:var(--fm);font-size:18px;font-weight:700;color:var(--or);"><?=$m['score1']?> – <?=$m['score2']?></td>
        <td style="color:var(--gr);font-weight:700;font-size:13px;"><?=htmlspecialchars($w)?></td>
        <td style="font-size:12px;color:var(--mu2);"><?=$m['match_date']?></td>
      </tr>
      <?php endforeach;?>
    </tbody>
  </table>
</div>
<?php endif;?>

<?php /* ══════ HISTORY ══════ */ elseif($tab==='history'): ?>
<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px;">
  <div style="font-family:var(--fh);font-size:22px;letter-spacing:.05em;">All <span style="color:var(--or);">Completed</span> Matches</div>
  <span class="tag td"><?=count($previousMatches)?> Matches</span>
</div>
<?php if($previousMatches): $rcolors=['win'=>'var(--gr)','loss'=>'var(--rd)','draw'=>'var(--yw)',''=>'transparent'];?>
<div style="display:flex;flex-direction:column;gap:11px;">
  <?php foreach($previousMatches as $m):
    $w=$m['winner']==1?$m['team1_name']:($m['winner']==2?$m['team2_name']:'Draw');
    $isMy=($m['team1_id']==$myTeamId||$m['team2_id']==$myTeamId);
    $res='';
    if($isMy&&$myTeamId){
      if($m['winner']==0)$res='draw';
      elseif(($m['winner']==1&&$m['team1_id']==$myTeamId)||($m['winner']==2&&$m['team2_id']==$myTeamId))$res='win';
      else $res='loss';
    }
  ?>
  <div class="card" style="padding:15px 18px;border-left:3px solid <?=$rcolors[$res]?>;">
    <div style="display:flex;align-items:center;gap:16px;flex-wrap:wrap;">
      <div style="flex:1;min-width:150px;">
        <div style="font-size:11px;color:var(--mu2);margin-bottom:3px;"><?=htmlspecialchars($m['tournament_name'])?> · <?=ucfirst($m['match_type']??'')?></div>
        <div style="font-family:var(--fh);font-size:18px;letter-spacing:.04em;"><?=htmlspecialchars($m['team1_name'])?> <span style="color:var(--mu);font-size:13px;">vs</span> <?=htmlspecialchars($m['team2_name'])?></div>
      </div>
      <div style="text-align:center;"><div style="font-size:10px;color:var(--mu);text-transform:uppercase;letter-spacing:.06em;margin-bottom:2px;">Score</div><div style="font-family:var(--fm);font-size:22px;font-weight:700;color:var(--or);"><?=$m['score1']?> – <?=$m['score2']?></div></div>
      <div style="text-align:center;"><div style="font-size:10px;color:var(--mu);text-transform:uppercase;letter-spacing:.06em;margin-bottom:2px;">Winner</div><div style="font-weight:700;color:var(--gr);font-size:13px;"><?=htmlspecialchars($w)?></div></div>
      <?php if($res):?><div style="text-align:center;"><div style="font-size:10px;color:var(--mu);text-transform:uppercase;letter-spacing:.06em;margin-bottom:2px;">My Result</div><span class="tag" style="color:<?=$rcolors[$res]?>;border-color:<?=$rcolors[$res]?>;background:transparent;"><?=strtoupper($res)?></span></div><?php endif;?>
      <div style="text-align:right;font-size:11px;color:var(--mu2);"><?=$m['match_date']?><br><?=date('h:i A',strtotime($m['match_time']))?></div>
      <a href="?tab=live&match_id=<?=$m['id']?>" class="btn btn-g btn-sm">▶ Replay</a>
    </div>
  </div>
  <?php endforeach;?>
</div>
<?php else:?><div class="empty card"><div class="ei">📭</div><div class="et">No Match History</div><div class="es">Completed matches will appear here.</div></div><?php endif;?>

<?php /* ══════ TEAM ══════ */ elseif($tab==='team'): ?>
<?php if(!$myTeamId):?>
<div class="empty card"><div class="ei">👥</div><div class="et">Not Assigned to a Team</div><div class="es">Contact your organizer to be added to a team.</div></div>
<?php else:?>
<!-- Team Hero -->
<div style="background:linear-gradient(135deg,var(--s1),var(--s2));border:1px solid var(--bd2);border-radius:16px;padding:24px 28px;margin-bottom:20px;display:flex;align-items:center;gap:22px;position:relative;overflow:hidden;">
  <div style="position:absolute;right:-30px;top:-30px;width:160px;height:160px;border-radius:50%;background:radial-gradient(circle,rgba(26,171,255,.1),transparent 70%);"></div>
  <div style="width:60px;height:60px;border-radius:50%;background:linear-gradient(135deg,var(--bl),var(--pu));display:flex;align-items:center;justify-content:center;font-size:26px;flex-shrink:0;">⚽</div>
  <div>
    <div style="font-size:10px;text-transform:uppercase;letter-spacing:.1em;color:var(--mu2);margin-bottom:4px;">My Team</div>
    <div style="font-family:var(--fh);font-size:30px;letter-spacing:.04em;"><?=htmlspecialchars($myTeamName)?></div>
    <?php if($myTournament):?><div style="font-size:13px;color:var(--mu2);margin-top:4px;">🏆 <?=htmlspecialchars($myTournament['name'])?> · <?=ucfirst($myTournament['match_type']??'')?></div><?php endif;?>
  </div>
  <div style="flex:1;"></div>
  <div style="text-align:center;padding:14px 22px;background:var(--s3);border-radius:12px;">
    <div style="font-family:var(--fh);font-size:38px;color:var(--or);"><?=$myTeamPoints?></div>
    <div style="font-size:10px;color:var(--mu2);text-transform:uppercase;letter-spacing:.06em;font-weight:700;">Points</div>
  </div>
</div>
<div class="g2">
  <!-- Team Matches -->
  <div class="card">
    <div class="ch"><div class="ct">Team Matches</div>
      <div style="display:flex;gap:6px;"><span class="tag td" style="font-size:10px;"><?=$myMatchesWon?>W</span><span class="tag tl" style="font-size:10px;"><?=$myMatchesLost?>L</span><span class="tag ty" style="font-size:10px;"><?=$myMatchesDraw?>D</span></div>
    </div>
    <?php if($myMatches):?>
    <table class="tbl">
      <thead><tr><th>Opponent</th><th>Score</th><th>Result</th></tr></thead>
      <tbody>
        <?php foreach($myMatches as $m):
          $opp=$m['team1_id']==$myTeamId?$m['team2_name']:$m['team1_name'];
          if(!$m['played']){$res='—';$rc='var(--mu2)';}
          elseif($m['winner']==0){$res='Draw';$rc='var(--yw)';}
          elseif(($m['winner']==1&&$m['team1_id']==$myTeamId)||($m['winner']==2&&$m['team2_id']==$myTeamId)){$res='Win';$rc='var(--gr)';}
          else{$res='Loss';$rc='var(--rd)';}
        ?>
        <tr>
          <td><div style="font-weight:600;"><?=htmlspecialchars($opp)?></div><div style="font-size:11px;color:var(--mu2);"><?=$m['match_date']?></div></td>
          <td style="font-family:var(--fm);font-weight:700;color:var(--or);"><?=$m['played']?$m['score1'].'–'.$m['score2']:'TBD'?></td>
          <td><span style="color:<?=$rc?>;font-weight:700;font-size:13px;"><?=$res?></span></td>
        </tr>
        <?php endforeach;?>
      </tbody>
    </table>
    <?php else:?><div class="empty"><div class="es">No matches for your team yet.</div></div><?php endif;?>
  </div>
  <!-- Teammates -->
  <div class="card">
    <div class="ch"><div class="ct">Teammates</div><span class="tag ts"><?=count($teammates)+1?> Players</span></div>
    <!-- Me -->
    <div style="display:flex;align-items:center;gap:11px;padding:10px;background:rgba(255,92,26,.07);border:1px solid rgba(255,92,26,.2);border-radius:9px;margin-bottom:9px;">
      <div style="width:34px;height:34px;border-radius:50%;background:linear-gradient(135deg,var(--or),var(--bl));display:flex;align-items:center;justify-content:center;font-weight:800;font-size:12px;flex-shrink:0;"><?=$initials?></div>
      <div style="flex:1;">
        <div style="font-weight:700;font-size:13px;"><?=htmlspecialchars($player['name'])?> <span style="color:var(--or);font-size:10px;font-weight:800;">(YOU)</span></div>
        <div style="font-size:11px;color:var(--mu2);"><?=htmlspecialchars($player['position']??'Player')?></div>
        <?php if($player['skill']):?><div class="sk-bar"><div class="sk-fill" style="width:<?=min(100,$player['skill'])?>%;"></div></div><?php endif;?>
      </div>
      <div style="font-family:var(--fm);font-size:14px;font-weight:700;color:var(--yw);"><?=$player['skill']??'—'?></div>
    </div>
    <?php foreach($teammates as $tm): $ti=strtoupper(substr($tm['user_name']??'T',0,2));?>
    <div style="display:flex;align-items:center;gap:11px;padding:10px;border-bottom:1px solid var(--bd);">
      <div style="width:32px;height:32px;border-radius:50%;background:var(--s3);display:flex;align-items:center;justify-content:center;font-size:11px;font-weight:700;flex-shrink:0;"><?=$ti?></div>
      <div style="flex:1;">
        <div style="font-weight:600;font-size:13px;"><?=htmlspecialchars($tm['user_name']??'Player')?></div>
        <div style="font-size:11px;color:var(--mu2);"><?=htmlspecialchars($tm['position']??'—')?></div>
        <?php if($tm['skill']):?><div class="sk-bar"><div class="sk-fill" style="width:<?=min(100,$tm['skill'])?>%;"></div></div><?php endif;?>
      </div>
      <div style="font-family:var(--fm);font-size:13px;font-weight:700;color:var(--yw);"><?=$tm['skill']??'—'?></div>
    </div>
    <?php endforeach;?>
  </div>
</div>
<?php endif;?>

<?php /* ══════ STANDINGS ══════ */ elseif($tab==='standings'): ?>
<?php if(!$myTournamentId):?>
<div class="empty card"><div class="ei">🏅</div><div class="et">No Tournament Assigned</div><div class="es">You need to be part of a team in a tournament to see standings.</div></div>
<?php elseif(!$standings):?>
<div class="empty card"><div class="ei">📊</div><div class="et">No Standings Yet</div><div class="es">Standings update once matches are played.</div></div>
<?php else:?>
<div style="margin-bottom:16px;">
  <div style="font-family:var(--fh);font-size:22px;letter-spacing:.05em;">Tournament <span style="color:var(--or);">Standings</span></div>
  <div style="font-size:13px;color:var(--mu2);margin-top:4px;">🏆 <?=htmlspecialchars($myTournament['name']??'')?> &nbsp;·&nbsp; <?=ucfirst($myTournament['match_type']??'')?></div>
</div>
<div class="card">
  <table class="tbl">
    <thead><tr><th>#</th><th>Team</th><th>Played</th><th>W</th><th>D</th><th>L</th><th>Points</th></tr></thead>
    <tbody>
      <?php foreach($standings as $i=>$row):
        $isMe=($row['name']===$myTeamName);
        $pos=$i+1;
        $medal=$pos==1?'🥇':($pos==2?'🥈':($pos==3?'🥉':''));
      ?>
      <tr <?=$isMe?'class="my-row"':''?>>
        <td style="font-family:var(--fm);font-weight:700;color:var(--mu2);"><?=$medal?:$pos?></td>
        <td><span style="font-weight:700;"><?=htmlspecialchars($row['name'])?></span><?php if($isMe):?> <span class="tag tl" style="font-size:9px;margin-left:6px;">YOU</span><?php endif;?></td>
        <td style="color:var(--mu2);"><?=$row['played']?></td>
        <td style="color:var(--gr);font-weight:700;"><?=$row['wins']?></td>
        <td style="color:var(--yw);"><?=$row['draws']?></td>
        <td style="color:var(--rd);"><?=$row['losses']?></td>
        <td><span style="font-family:var(--fm);font-size:16px;font-weight:800;color:var(--or);"><?=$row['points']?></span></td>
      </tr>
      <?php endforeach;?>
    </tbody>
  </table>
</div>
<?php endif;?>

<?php /* ══════ ACCOUNT ══════ */ elseif($tab==='account'): ?>
<?php if(isset($_GET['updated'])):?><div class="alert a-ok">✅ Profile updated successfully!</div><?php endif;?>
<?php if($pwSuccess):?><div class="alert a-ok">🔒 <?=$pwSuccess?></div><?php endif;?>
<?php if($pwError):?><div class="alert a-er">⚠️ <?=$pwError?></div><?php endif;?>

<!-- Profile Hero -->
<div class="phero">
  <div class="av-xl"><?=$initials?></div>
  <div>
    <div class="ph-nm"><?=htmlspecialchars($player['name'])?></div>
    <div class="ph-rl">⚡ <?=ucfirst($player['role'])?></div>
    <div class="ph-mt">
      📧 <?=htmlspecialchars($player['email'])?><br>
      <?php if($player['phone']):?>📞 <?=htmlspecialchars($player['phone'])?><br><?php endif;?>
      <?php if($player['position']):?>🎯 <?=htmlspecialchars($player['position'])?>&nbsp;&nbsp;<?php endif;?>
      <?php if($player['skill']):?>⭐ Skill <?=$player['skill']?>/100<?php endif;?>
    </div>
  </div>
  <div style="flex:1;"></div>
  <div style="text-align:right;"><div style="font-size:11px;color:var(--mu);margin-bottom:6px;">Plan</div><span class="tag ty"><?=ucfirst($player['subscription'])?></span></div>
</div>

<div class="g2">
  <!-- Edit Profile -->
  <div class="card">
    <div class="ch"><div class="ct">Edit Profile</div></div>
    <form method="POST">
      <div class="frow">
        <div class="fg"><label class="fl">Full Name</label><input type="text" name="name" class="fi" value="<?=htmlspecialchars($player['name']??'')?>" required></div>
        <div class="fg"><label class="fl">Email</label><input type="email" name="email" class="fi" value="<?=htmlspecialchars($player['email']??'')?>" required></div>
      </div>
      <div class="frow">
        <div class="fg"><label class="fl">Phone</label><input type="text" name="phone" class="fi" value="<?=htmlspecialchars($player['phone']??'')?>"></div>
        <div class="fg"><label class="fl">Date of Birth</label><input type="date" name="dob" class="fi" value="<?=$player['dob']??''?>"></div>
      </div>
      <div class="frow">
        <div class="fg"><label class="fl">Position / Role</label><input type="text" name="position" class="fi" placeholder="e.g. Midfielder, Point Guard…" value="<?=htmlspecialchars($player['position']??'')?>"></div>
        <div class="fg"><label class="fl">Skill (set by organizer)</label><input type="text" class="fi" value="<?=$player['skill']??'N/A'?>" disabled style="opacity:.5;cursor:not-allowed;"></div>
      </div>
      <div class="fg"><label class="fl">Address</label><textarea name="address" class="fta"><?=htmlspecialchars($player['address']??'')?></textarea></div>
      <button type="submit" name="update_profile" class="btn btn-p btn-bl">💾 Save Changes</button>
    </form>
  </div>

  <div style="display:flex;flex-direction:column;gap:16px;">
    <!-- Password -->
    <div class="card">
      <div class="ch"><div class="ct">Change Password</div></div>
      <form method="POST">
        <div class="fg"><label class="fl">Current Password</label><input type="password" name="current_password" class="fi" required></div>
        <div class="frow">
          <div class="fg"><label class="fl">New Password</label><input type="password" name="new_password" class="fi" required></div>
          <div class="fg"><label class="fl">Confirm New</label><input type="password" name="confirm_password" class="fi" required></div>
        </div>
        <button type="submit" name="change_password" class="btn btn-d btn-bl">🔒 Update Password</button>
      </form>
    </div>
    <!-- Subscription -->
    <div class="card">
      <div class="ch"><div class="ct">My Subscription</div></div>
      <div style="text-align:center; padding:10px 0;">
        <?php if($player['is_paid'] ?? 0): ?>
          <div style="font-size:32px; margin-bottom:5px;">✅</div>
          <div style="color:var(--gr); font-weight:700; font-size:16px;">Active Subscription</div>
          <div style="font-size:12px; color:var(--mu2); margin-top:5px;">You are fully subscribed to the <?=htmlspecialchars($player['subscription'])?>!</div>
        <?php else: 
          $endDate = $player['trial_ends_at'] ?: date('Y-m-d H:i:s', strtotime('+30 days'));
          $daysLeft = max(0, ceil((strtotime($endDate) - time()) / 86400));
        ?>
          <div style="font-size:32px; margin-bottom:5px;">⏳</div>
          <div style="color:var(--or); font-weight:700; font-size:16px;"><?=$daysLeft?> Days Left in Free Trial</div>
          <div style="font-size:12px; color:var(--mu2); margin-top:5px; margin-bottom:15px;">Your trial ends on <?=date('M d, Y', strtotime($endDate))?>.</div>
          <a href="payment.php" class="btn btn-p btn-bl">💳 Secure Your Subscription</a>
        <?php endif; ?>
      </div>
    </div>
    <!-- Stats -->
    <div class="card">
      <div class="ch"><div class="ct">My Stats</div></div>
      <?php $rows=[['🏟','Total Matches',count($allMatches)],['✅','Wins',$myMatchesWon],['❌','Losses',$myMatchesLost],['🤝','Draws',$myMatchesDraw],['🏅','Team Points',$myTeamPoints],['👥','Teammates',count($teammates)]];
      foreach($rows as[$ic,$lb,$vl]):?>
      <div style="display:flex;align-items:center;justify-content:space-between;padding:8px 0;border-bottom:1px solid var(--bd);">
        <div style="font-size:13px;color:var(--mu2);"><?=$ic?> <?=$lb?></div>
        <div style="font-family:var(--fm);font-size:16px;font-weight:700;color:var(--or);"><?=$vl?></div>
      </div>
      <?php endforeach;?>
    </div>
  </div>
</div>

<?php endif; /* end tabs */ ?>
</main>
</div><!-- .app -->
</body>
</html>