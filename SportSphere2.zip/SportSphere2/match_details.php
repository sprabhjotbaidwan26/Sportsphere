<?php
require "config/db.php";
require "auth_check.php";
require "role_check.php";

allowRoles(['organizer','player','spectator']);

$id = $_GET['id'] ?? null;

if(!$id){
    echo "No match selected";
    exit();
}

// FETCH MATCH
$stmt = $pdo->prepare("
SELECT m.*, 
       t1.name AS team1, 
       t2.name AS team2,
       tr.name AS tournament
FROM matches m
JOIN teams t1 ON m.team1_id = t1.id
JOIN teams t2 ON m.team2_id = t2.id
JOIN tournaments tr ON m.tournament_id = tr.id
WHERE m.id = ?
");
$stmt->execute([$id]);
$m = $stmt->fetch();

if(!$m){
    echo "Match not found";
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Match Details</title>
<link href="https://fonts.googleapis.com/css2?family=Barlow+Condensed:wght@700;900&family=Barlow:wght@400;500;600&display=swap" rel="stylesheet">

<style>
:root{
 --orange:#FF5C1A;
 --dark:#0F0F0F;
 --card:#1A1A1A;
 --border:rgba(255,255,255,0.08);
 --text:#F5F5F5;
 --muted:#777;
}

/* BODY */
body{
 margin:0;
 display:flex;
 background:var(--dark);
 color:var(--text);
 font-family:'Barlow',sans-serif;
}

/* SIDEBAR */
.sidebar{
 width:220px;
 background:#111;
 height:100vh;
 padding:20px;
 border-right:1px solid var(--border);
}

.sidebar h2{
 color:var(--orange);
 margin-bottom:20px;
}

.sidebar a{
 display:block;
 color:#aaa;
 text-decoration:none;
 padding:10px 0;
}

.sidebar a:hover{
 color:#fff;
}

/* MAIN */
.main{
 flex:1;
 padding:30px;
}

/* HEADER */
h2{
 font-family:'Barlow Condensed',sans-serif;
 letter-spacing:1px;
}

/* CARD */
.card{
 background:var(--card);
 padding:25px;
 border-radius:10px;
 border:1px solid var(--border);
 max-width:600px;
 margin:auto;
 text-align:center;
}

/* BUTTON */
button{
 background:var(--orange);
 border:none;
 padding:10px 15px;
 color:#fff;
 border-radius:6px;
 cursor:pointer;
 margin-top:15px;
}

button:hover{
 background:#cc4200;
}

/* BACK BUTTON */
.back-btn{
 background:#333;
}

.back-btn:hover{
 background:#555;
}

/* SCORE */
.score{
 font-size:48px;
 font-weight:900;
 color:var(--orange);
 margin:15px 0;
}

/* INFO */
.info{
 margin:10px 0;
 font-size:16px;
 color:#ccc;
}
</style>
</head>

<body>

<!-- SIDEBAR -->
<div class="sidebar">
  <h2>🏀 SportSphere</h2>

  <a href="dashboard.php">📊 Dashboard</a>
  <a href="tournaments.php">🏆 Tournaments</a>
  <a href="teams.php">👥 Teams</a>
  <a href="matches.php">📅 Matches</a>
  <a href="players.php">🏀 Players</a>
  <a href="leaderboard.php">🏅 Leaderboard</a>
  <a href="ads.php">📢 Manage Ads</a>
  <a href="auth/logout.php">🚪 Logout</a>
</div>

<!-- MAIN -->
<div class="main">
<div class="container">

<div class="card">

<h2>Match Details</h2>

<h3><?= htmlspecialchars($m['team1']) ?> vs <?= htmlspecialchars($m['team2']) ?></h3>

<div class="score">
<?= $m['score1'] ?? 0 ?> - <?= $m['score2'] ?? 0 ?>
</div>

<p class="info">
Date: <?= htmlspecialchars($m['match_date']) ?> |
Time: <?= date("h:i A", strtotime($m['match_time'])) ?>
</p>

<p class="info">Tournament: <?= htmlspecialchars($m['tournament']) ?></p>

<a href="matches.php">
<button>⬅ Back to Matches</button>
</a>

</div>

<a href="dashboard.php">
<button class="back-btn">⬅ Dashboard</button>
</a>

</div>
</div>

</body>
</html>