<?php
require "config/db.php";
require "auth_check.php";
require "role_check.php";

allowRoles(['organizer']);

header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename=sportsphere_report_' . date("Y-m-d") . '.csv');

$output = fopen('php://output', 'w');

// Leaderboard Section
fputcsv($output, ['=============================']);
fputcsv($output, ['LEADERBOARD SUMMARY']);
fputcsv($output, ['=============================']);
fputcsv($output, ['Rank', 'Team Name', 'Total Points']);

$leaderboard = $pdo->query("SELECT name, points FROM teams ORDER BY points DESC")->fetchAll(PDO::FETCH_ASSOC);

$rank = 1;
foreach($leaderboard as $row) {
    fputcsv($output, [$rank++, $row['name'], $row['points']]);
}

fputcsv($output, []);
fputcsv($output, []);

// Matches Section
fputcsv($output, ['=============================']);
fputcsv($output, ['MATCH HISTORY REPORT']);
fputcsv($output, ['=============================']);
fputcsv($output, ['Date', 'Time', 'Home Team', 'Away Team', 'Home Score', 'Away Score', 'Winner']);

$matches = $pdo->query("
SELECT 
 m.match_date, m.match_time, m.score1, m.score2, m.winner,
 t1.name AS team1,
 t2.name AS team2
FROM matches m
JOIN teams t1 ON m.team1_id = t1.id
JOIN teams t2 ON m.team2_id = t2.id
WHERE played=1
ORDER BY m.match_date DESC
")->fetchAll(PDO::FETCH_ASSOC);

foreach($matches as $m) {
    $winner_name = "Draw";
    if($m['winner'] == 1) $winner_name = $m['team1'];
    if($m['winner'] == 2) $winner_name = $m['team2'];

    fputcsv($output, [
        $m['match_date'],
        $m['match_time'],
        $m['team1'],
        $m['team2'],
        $m['score1'],
        $m['score2'],
        $winner_name
    ]);
}

fclose($output);
exit();
?>
