<?php
require "config/db.php"; 
require "auth_check.php"; 
require "role_check.php";

allowRoles(['organizer','player','spectator']); 

// Fetch Active Ads
try {
    $active_ads = $pdo->query("SELECT ad_text FROM ads WHERE is_active = 1")->fetchAll(PDO::FETCH_COLUMN);
} catch (PDOException $e) {
    $active_ads = [];
}

$userId = $_SESSION['user'] ?? null;
if (!$userId) { header("Location: auth/login.php"); exit; }

$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$userId]);
$spectator = $stmt->fetch(PDO::FETCH_ASSOC);

// Handle profile update
if ($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['update_profile'])) {
    $upd = $pdo->prepare("UPDATE users SET name=?,email=?,phone=?,dob=?,address=? WHERE id=?");
    $upd->execute([
        trim($_POST['name']), trim($_POST['email']), trim($_POST['phone']),
        trim($_POST['dob']) ?: null, trim($_POST['address']),
        $userId
    ]);
    header("Location: spectatordashboard.php?tab=account&updated=1"); exit;
}

// Handle password change
$pwError = $pwSuccess = '';
if ($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['change_password'])) {
    $current = $_POST['current_password'];
    $new     = $_POST['new_password'];
    $confirm = $_POST['confirm_password'];
    if (!password_verify($current, $spectator['password'])) $pwError = 'Current password is incorrect.';
    elseif (strlen($new) < 6)                               $pwError = 'New password must be at least 6 characters.';
    elseif ($new !== $confirm)                              $pwError = 'Passwords do not match.';
    else {
        $pdo->prepare("UPDATE users SET password=? WHERE id=?")->execute([password_hash($new,PASSWORD_DEFAULT),$userId]);
        $pwSuccess = 'Password updated successfully!';
        $stmt->execute([$userId]); $spectator = $stmt->fetch(PDO::FETCH_ASSOC);
    }
}

$tab = $_GET['tab'] ?? 'matches';

// Fetch all matches
$allMatches = $pdo->query("
    SELECT m.*, 
           t1.name AS team1_name,
           t2.name AS team2_name,
           tr.name AS tournament_name
    FROM matches m
    JOIN teams t1 ON m.team1_id = t1.id
    JOIN teams t2 ON m.team2_id = t2.id
    JOIN tournaments tr ON m.tournament_id = tr.id
    ORDER BY m.match_date DESC, m.match_time DESC
")->fetchAll();

$selectedId = isset($_GET['match_id']) ? (int)$_GET['match_id'] : null;

$liveMatch = null;
if($selectedId){
    foreach($allMatches as $m){
        if($m['id'] == $selectedId){
            $liveMatch = $m;
            break;
        }
    }
} 
if(!$liveMatch && count($allMatches)) $liveMatch = $allMatches[0];

// Function to get video URL
function getVideo($match){
    if(!$match['played']) return null;
    if(strtolower($match['team1_name']) == 'team a' && strtolower($match['team2_name']) == 'team b') return "https://www.youtube.com/embed/a0P4WeUURks?start=7";
    if(strtolower($match['team1_name']) == 'team b' && strtolower($match['team2_name']) == 'team a') return "https://www.youtube.com/embed/kKR86MLPegA";
    return "https://www.youtube.com/embed/a0P4WeUURks"; // default
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>SportSphere Spectator</title>
<link href="https://fonts.googleapis.com/css2?family=Barlow+Condensed:wght@700;900&family=Barlow:wght@400;500;600&display=swap" rel="stylesheet">
<style>
:root{
  --orange:#FF5C1A;
  --dark:#0F0F0F;
  --card:#1A1A1A;
  --border:rgba(255,255,255,0.08);
  --text:#F5F5F5;
  --muted:#777;
  --green:#0F0;
  --red:#FF4D4D;
  --blue:#1E90FF;
  --shadow: rgba(0,0,0,0.5);
}
*{box-sizing:border-box;}
body{margin:0; display:flex; font-family:'Barlow',sans-serif; background:var(--dark); color:var(--text);}
.sidebar{
  width:250px;
  background:#111;
  padding:20px;
  border-right:1px solid var(--border);
  height:100vh;
  overflow-y:auto;
}
.sidebar h2{color:var(--orange); margin-bottom:20px;}
.sidebar a{
  display:block;
  padding:10px;
  text-decoration:none;
  color:#aaa;
  border-radius:6px;
  margin-bottom:5px;
  transition:0.2s;
}
.sidebar a:hover, .sidebar a.active{background:var(--orange); color:#000;}
.main{flex:1; padding:30px; overflow-y:auto;}
.rightbar{
  width:250px;
  background:#111;
  padding:20px;
  border-left:1px solid var(--border);
  height:100vh;
  overflow-y:auto;
}
.scoreboard{
  display:flex;
  justify-content:space-between;
  align-items:center;
  background:var(--card);
  padding:20px 40px;
  border-radius:12px;
  margin-bottom:25px;
  box-shadow:0 5px 15px var(--shadow);
}
.team{display:flex; flex-direction:column; align-items:center; gap:10px;}
.team-name{font-size:22px; font-weight:700;}
.team-score{font-size:48px; color:var(--orange); font-weight:900;}
.vs{font-size:36px; font-weight:900; color:var(--muted);}
.video-container{display:flex; justify-content:center; margin-bottom:25px;}
iframe{width:100%; max-width:900px; height:500px; border-radius:15px; border:none; box-shadow:0 5px 20px var(--shadow);}
.card{background:var(--card); padding:20px; border-radius:12px; border:1px solid var(--border); margin-bottom:30px;}
.card h3{margin-bottom:15px; color:var(--orange); font-weight:900;}
.card table{width:100%; border-collapse:collapse;}
.card table th, .card table td{padding:12px; text-align:left; border-bottom:1px solid var(--border);}
.status-badge{padding:5px 12px; border-radius:12px; font-weight:700; font-size:14px;}
.status-notplayed{background:#777;color:#fff;}
.status-live{background:var(--orange);color:#fff;}
.status-finished{background:var(--green);color:#000;}
input, textarea { width:100%; padding:12px; background:#222; border:1px solid var(--border); color:#fff; border-radius:6px; margin-bottom:15px; font-family:'Barlow'; font-size:15px; }
input:focus, textarea:focus { border-color:var(--orange); outline:none; }
.btn { background: var(--orange); padding:12px 20px; border:none; border-radius:6px; color:#fff; cursor:pointer; font-weight:bold; width:100%; font-size:16px; transition:0.2s; }
.btn:hover { background: #cc4200; }
.btn-red { background: #331111; color: var(--red); border: 1px solid var(--red); }
.alert { padding:15px; border-radius:6px; margin-bottom:20px; font-weight:600; }
.alert-ok { background:rgba(0,255,0,0.1); border:1px solid var(--green); color:var(--green); }
.alert-err { background:rgba(255,0,0,0.1); border:1px solid var(--red); color:var(--red); }
label { display:block; margin-bottom:5px; color:#aaa; font-weight:600; font-size:13px; text-transform:uppercase; letter-spacing:1px; }

.topbar { display:flex; justify-content:flex-end; margin-bottom:20px; }
.logout-btn { background:var(--blue); color:#fff; padding:10px 18px; border-radius:6px; text-decoration:none; font-weight:700; transition:0.2s; }
.logout-btn:hover { background:#0055cc; }

.notice { text-align:center; background:#222; padding:30px; border-radius:12px; margin-bottom:20px; border:1px solid var(--border);}
@media(max-width:1200px){body{flex-direction:column;} .sidebar,.rightbar{width:100%; height:auto; border:none; border-bottom:1px solid var(--border);} iframe{height:300px;}.scoreboard{flex-direction:column; gap:15px; text-align:center;} .vs{display:none;}}
</style>
</head>
<body>

<!-- LEFT SIDEBAR -->
<div class="sidebar">
  <h2>🏀 SportSphere</h2>
  <a href="?tab=matches" class="<?= $tab === 'matches' ? 'active' : '' ?>">📺 Live Matches</a>
  <a href="?tab=account" class="<?= $tab === 'account' ? 'active' : '' ?>">⚙️ My Settings</a>
  <hr style="border:0; border-top:1px solid var(--border); margin:20px 0;">
  <?php if($tab === 'matches'): ?>
    <h3 style="color:#aaa; font-size:14px; text-transform:uppercase;">Previous Matches</h3>
    <?php foreach($allMatches as $m): ?>
      <?php if($m['played']): ?>
      <a href="?tab=matches&match_id=<?= $m['id'] ?>" style="font-size:14px; padding:8px;"><?= htmlspecialchars($m['team1_name']) ?> vs <?= htmlspecialchars($m['team2_name']) ?></a>
      <?php endif; ?>
    <?php endforeach; ?>
  <?php endif; ?>
</div>

<!-- MAIN CONTENT -->
<div class="main">
<div class="topbar">
  <a href="auth/logout.php" class="logout-btn">🔒 Logout</a>
</div>

<?php if(count($active_ads) > 0): ?>
<div style="background:#0a0a0a; border:1px solid var(--border); border-radius:12px; margin-bottom:25px; padding:12px 0; color:#fff; display:flex; align-items:center; overflow:hidden;">
  <marquee behavior="scroll" direction="left" scrollamount="6" style="flex:1;">
    <?php foreach($active_ads as $ad): ?>
      <span style="color:var(--orange); font-weight:700; margin-right:80px; font-size:16px;"><?= htmlspecialchars($ad) ?></span>
    <?php endforeach; ?>
  </marquee>
  <a href="mailto:admin@sportsphere.com?subject=Advertisement%20Inquiry" style="min-width:200px; padding:0 20px; color:#aaa; font-size:12px; text-transform:uppercase; letter-spacing:1px; text-decoration:none; display:flex; align-items:center; gap:8px; border-left:1px solid var(--border);">
    <span>📢 Advertise With Us</span>
  </a>
</div>
<?php endif; ?>

<?php if($tab === 'matches'): ?>
  <?php if($liveMatch): ?>
    <?php $videoUrl = getVideo($liveMatch); ?>
    <?php if($videoUrl): ?>
      <div class="scoreboard">
        <div class="team"><div class="team-name"><?= htmlspecialchars($liveMatch['team1_name']) ?></div><div class="team-score"><?= $liveMatch['score1'] ?? 0 ?></div></div>
        <div class="vs">VS</div>
        <div class="team"><div class="team-name"><?= htmlspecialchars($liveMatch['team2_name']) ?></div><div class="team-score"><?= $liveMatch['score2'] ?? 0 ?></div></div>
      </div>
      <div class="video-container">
        <iframe src="<?= $videoUrl ?>" frameborder="0" allowfullscreen></iframe>
      </div>
    <?php else: ?>
      <div class="notice">
        ⏳ Upcoming Match<br>
        <?= htmlspecialchars($liveMatch['team1_name']) ?> vs <?= htmlspecialchars($liveMatch['team2_name']) ?><br>
        Date: <?= $liveMatch['match_date'] ?> | Time: <?= date("h:i A", strtotime($liveMatch['match_time'])) ?>
      </div>
    <?php endif; ?>

    <!-- MATCH DETAILS TABLE -->
    <div class="card">
      <h3>Match Details</h3>
      <table>
        <tr><th>Tournament</th><td><?= htmlspecialchars($liveMatch['tournament_name']) ?></td></tr>
        <tr><th>Team 1</th><td><?= htmlspecialchars($liveMatch['team1_name']) ?></td></tr>
        <tr><th>Team 2</th><td><?= htmlspecialchars($liveMatch['team2_name']) ?></td></tr>
        <tr><th>Date</th><td><?= $liveMatch['match_date'] ?></td></tr>
        <tr><th>Time</th><td><?= date("h:i A", strtotime($liveMatch['match_time'])) ?></td></tr>
        <tr><th>Score</th><td><?= $liveMatch['played'] ? ($liveMatch['score1'].' - '.$liveMatch['score2']) : 'Not Played' ?></td></tr>
        <tr><th>Status</th>
          <td><span class="status-badge <?= $liveMatch['played'] ? 'status-finished' : 'status-notplayed' ?>"><?= $liveMatch['played'] ? 'Finished' : 'Not Played' ?></span></td>
        </tr>
        <tr><th>Winner</th>
          <td>
          <?php
          if(!$liveMatch['played']) echo '-';
          elseif($liveMatch['winner']==1) echo $liveMatch['team1_name'];
          elseif($liveMatch['winner']==2) echo $liveMatch['team2_name'];
          else echo 'Draw';
          ?>
          </td>
        </tr>
      </table>
    </div>

  <?php else: ?>
    <h2 style="text-align:center;">No matches available</h2>
  <?php endif; ?>
<?php elseif($tab === 'account'): ?>
  <!-- My Settings form here -->
  <h1 style="color:var(--orange); font-family:'Barlow Condensed',sans-serif; font-size:36px;">My Settings</h1>
  <?php if(isset($_GET['updated'])):?><div class="alert alert-ok">✅ Profile updated successfully!</div><?php endif;?>
  <?php if($pwSuccess):?><div class="alert alert-ok">🔒 <?=$pwSuccess?></div><?php endif;?>
  <?php if($pwError):?><div class="alert alert-err">⚠️ <?=$pwError?></div><?php endif;?>
  <div style="display:flex; gap:30px; flex-wrap:wrap;">
    <div class="card" style="flex:1; min-width:300px;">
      <h3>Edit Profile</h3>
      <form method="POST">
        <label>Full Name</label>
        <input type="text" name="name" value="<?=htmlspecialchars($spectator['name']??'')?>" required>
        <label>Email Address</label>
        <input type="email" name="email" value="<?=htmlspecialchars($spectator['email']??'')?>" required>
        <label>Phone Number</label>
        <input type="text" name="phone" value="<?=htmlspecialchars($spectator['phone']??'')?>">
        <label>Date of Birth</label>
        <input type="date" name="dob" value="<?=$spectator['dob']??''?>">
        <label>Address</label>
        <textarea name="address"><?=htmlspecialchars($spectator['address']??'')?></textarea>
        <button type="submit" name="update_profile" class="btn">💾 Save Profile</button>
      </form>
    </div>
    <div style="flex:1; min-width:300px; display:flex; flex-direction:column; gap:30px;">
      <div class="card" style="margin-bottom:0; text-align:center; padding:30px;">
        <h3>My Subscription</h3>
        <?php if($spectator['is_paid'] ?? 0): ?>
          <div style="font-size:40px; margin-bottom:10px;">✅</div>
          <div style="color:var(--green); font-weight:700; font-size:22px;">Active Subscription</div>
          <div style="font-size:15px; color:var(--muted); margin-top:5px;">You are fully subscribed to the <?=htmlspecialchars($spectator['subscription'])?>!</div>
        <?php else: 
          $endDate = $spectator['trial_ends_at'] ?: date('Y-m-d H:i:s', strtotime('+30 days'));
          $daysLeft = max(0, ceil((strtotime($endDate) - time()) / 86400));
        ?>
          <div style="font-size:40px; margin-bottom:10px;">⏳</div>
          <div style="color:var(--orange); font-weight:900; font-size:22px;"><?=$daysLeft?> Days Left</div>
          <div style="font-size:14px; color:var(--muted); margin-top:5px; margin-bottom:20px;">Your free trial ends on <?=date('M d, Y', strtotime($endDate))?>.</div>
          <a href="payment.php" style="text-decoration:none;"><button class="btn">💳 Secure Your Subscription</button></a>
        <?php endif; ?>
      </div>
      <div class="card" style="padding:20px; text-align:center;">
        <h3>Change Password</h3>
        <form method="POST">
          <label>Current Password</label>
          <input type="password" name="current_password" required>
          <label>New Password</label>
          <input type="password" name="new_password" required>
          <label>Confirm Password</label>
          <input type="password" name="confirm_password" required>
          <button type="submit" name="change_password" class="btn">🔒 Change Password</button>
        </form>
      </div>
    </div>
  </div>
<?php endif; ?>
</div>

<!-- RIGHT SIDEBAR -->
<!-- RIGHT SIDEBAR -->
<div class="rightbar">
  <h3 style="color:#aaa; font-size:14px; text-transform:uppercase; margin-bottom:15px;">Upcoming Matches</h3>
  <?php foreach($allMatches as $m): ?>
    <?php if(!$m['played']): ?>
      <a href="?tab=matches&match_id=<?= $m['id'] ?>" 
         style="display:block; padding:12px 15px; margin-bottom:12px; background:#1a1a1a; border-radius:10px; color:#fff; font-weight:600; font-size:16px; text-decoration:none; transition:0.2s; border:1px solid rgba(255,255,255,0.05);">
        <?= htmlspecialchars($m['team1_name']) ?> vs <?= htmlspecialchars($m['team2_name']) ?><br>
        <span style="font-size:13px; color:#aaa; margin-top:3px; display:block;">
          <?= date("M d, Y", strtotime($m['match_date'])) ?> | <?= date("h:i A", strtotime($m['match_time'])) ?>
        </span>
      </a>
    <?php endif; ?>
  <?php endforeach; ?>
</div>

<style>
.rightbar a:hover {
    background: var(--orange);
    color: #000;
    border-color: var(--orange);
}
</style>

</body>
</html>