<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

require "config/db.php";
require "auth_check.php";

// ✅ SAFE SESSION ACCESS
$user_id = $_SESSION['user'] ?? null;
$role = $_SESSION['role'] ?? '';

if(!$user_id){
 header("Location: auth/login.php");
 exit();
}

// ✅ FETCH USER SAFELY
$stmt = $pdo->prepare("SELECT name,email,subscription FROM users WHERE id=?");
$stmt->execute([$user_id]);
$u = $stmt->fetch();

// ❌ PREVENT BLANK PAGE
if(!$u){
 die("User not found in database!");
}

// UPDATE PROFILE
if(isset($_POST['update_profile'])){
 $pdo->prepare("UPDATE users SET name=?, email=? WHERE id=?")
 ->execute([$_POST['name'], $_POST['email'], $user_id]);
 header("Location: settings.php");
 exit();
}

// CHANGE PASSWORD
if(isset($_POST['change_password'])){
 $pass = password_hash($_POST['password'], PASSWORD_DEFAULT);
 $pdo->prepare("UPDATE users SET password=? WHERE id=?")
 ->execute([$pass, $user_id]);
 header("Location: settings.php");
 exit();
}

// DELETE ACCOUNT
if(isset($_POST['delete_account'])){
 $pdo->prepare("DELETE FROM users WHERE id=?")->execute([$user_id]);
 session_destroy();
 header("Location: auth/login.php");
 exit();
}
?>

<link rel="stylesheet" href="style.css">
<?php include "sidebar.php"; ?>

<div class="main">
<div class="container">

<h2>Settings</h2>

<!-- BACK -->
<a href="dashboard.php">
<button class="back-btn">⬅ Back</button>
</a>

<!-- PROFILE -->
<form method="POST" class="card">
<h3>Update Profile</h3>

<input name="name" value="<?= htmlspecialchars($u['name']) ?>" required>
<input name="email" value="<?= htmlspecialchars($u['email']) ?>" required>

<button name="update_profile">Update</button>
</form>

<!-- PASSWORD -->
<form method="POST" class="card">
<h3>Change Password</h3>

<input type="password" name="password" placeholder="New Password" required>

<button name="change_password">Change</button>
</form>

<!-- SUBSCRIPTION -->
<div class="card">
<h3>Subscription</h3>

<?php if($role == 'organizer'): ?>

<p style="color:#aaa;">
Organizer has full access (no subscription required).
</p>

<?php else: ?>

<p style="font-size:18px;">
Your Plan: <b><?= htmlspecialchars($u['subscription']) ?></b>
</p>

<?php if($role == 'player'): ?>
<p style="color:#aaa;">Access to tournaments, teams, and matches.</p>
<?php elseif($role == 'spectator'): ?>
<p style="color:#aaa;">Access to live matches and leaderboard.</p>
<?php endif; ?>

<?php endif; ?>

</div>

<!-- DELETE -->
<form method="POST" class="card" onsubmit="return confirmDelete()">
<h3>Delete Account</h3>

<button name="delete_account" style="background:red;">
Delete Account
</button>

</form>

</div>
</div>

<script>
function confirmDelete(){
 return confirm("⚠️ This action cannot be undone.\nAre you sure?");
}
</script>
