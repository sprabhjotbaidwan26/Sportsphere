<?php
require "config/db.php";

if(!isset($_SESSION['user'])){
 header("Location: auth/login.php");
 exit();
}

if(isset($_SESSION['is_paid']) && $_SESSION['is_paid'] == 1){
 if($_SESSION['role'] === 'player'){
   header("Location: playerdashboard.php");
 } else {
   header("Location: spectatordashboard.php");
 }
 exit();
}

//require "config/db.php";

// 🎯 SAFE DB FETCH (To fix old/corrupted sessions)
$stmt = $pdo->prepare("SELECT role, subscription, trial_ends_at FROM users WHERE id=?");
$stmt->execute([$_SESSION['user']]);
$db_user = $stmt->fetch(PDO::FETCH_ASSOC);

$role = $db_user ? strtolower($db_user['role']) : 'player';
$plan = $db_user && $db_user['subscription'] ? $db_user['subscription'] : 'Basic';
$trial_ends_at = $db_user ? $db_user['trial_ends_at'] : null;

// 🎯 FIX PRICE MAPPING (Use role if plan is basic)
if($plan == 'Player Plan' || $role == 'player'){
 $price = 5;
 $plan = 'Player Plan';
}
elseif($plan == 'Viewer Plan' || $role == 'spectator'){
 $price = 3;
 $plan = 'Viewer Plan';
}
else{
 $price = 0;
}

// Check if actually expired. If null, they are an old user, so give them a mock 30 days from now so it doesn't instantly show expired.
$effective_trial_end = $trial_ends_at ?: date('Y-m-d H:i:s', strtotime('+30 days'));
$trial_expired = (time() > strtotime($effective_trial_end));

// 🎯 HANDLE PAYMENT (DUMMY)
if(isset($_POST['pay'])){
 
 $stmt = $pdo->prepare("UPDATE users SET is_paid=1 WHERE id=?");
 $stmt->execute([$_SESSION['user']]);
 $_SESSION['is_paid'] = 1;

 if($_SESSION['role'] === 'player'){
   header("Location: playerdashboard.php");
 } else {
   header("Location: spectatordashboard.php");
 }
 exit();
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Payment Required</title>
<link rel="stylesheet" href="style.css">
</head>

<body class="auth-page">

<div class="card" style="max-width:400px; margin:auto; text-align:center;">

<h2 style="color:<?= $trial_expired ? '#FF4D4D' : '#4CAF50' ?>;">
  <?= $trial_expired ? 'Your Free Trial Has Expired' : 'Secure Your Subscription' ?>
</h2>

<p style="margin:20px 0;">
  <?= $trial_expired 
      ? 'To continue accessing <b>SportSphere</b>, please complete your subscription payment.' 
      : 'You still have time on your free trial, but you can secure your subscription now to avoid any interruption!' ?>
</p>

<p style="margin:10px 0; color:#aaa;">
Your Plan: <b><?= htmlspecialchars($plan) ?></b>
</p>

<p style="font-size:32px; color:#FF5C1A; font-weight:900;">
$<?= $price ?> / month
</p>

<!-- 💳 DUMMY PAYMENT FORM -->
<form method="POST">

<input placeholder="Card Number" required>
<div style="display:flex; gap:10px;">
  <input placeholder="MM/YY" style="flex:1;" required>
  <input placeholder="CVV" style="flex:1;" required>
</div>

<button name="pay" style="width:100%; margin-top:20px; font-size:18px; padding:15px; background:#4CAF50;">
Complete Payment ✓
</button>

</form>

<div style="margin-top:20px; display:flex; gap:20px; justify-content:center;">
  <?php if(!$trial_expired): ?>
  <a href="<?= $role === 'spectator' ? 'spectatordashboard.php?tab=account' : 'playerdashboard.php?tab=account' ?>" style="display:inline-block; color:#aaa; text-decoration:none;">
    ⬅ Back
  </a>
  <?php endif; ?>
  
  <a href="auth/logout.php" style="display:inline-block; color:#FF5C1A; text-decoration:none;">
    🚪 Logout
  </a>
</div>

</div>

</body>
</html>