<?php
require "config/db.php";
require "auth_check.php";
require "role_check.php";

allowRoles(['organizer','player','spectator']);

$user_id = $_SESSION['user'];
$role = $_SESSION['role'];

if(isset($_POST['add'])){
 $n = $pdo->query("SELECT name FROM users WHERE id=".(int)$_POST['user_id'])->fetchColumn();
 $pdo->prepare("INSERT INTO players(name, team_id, user_id) VALUES(?,?,?)")
 ->execute([$n, $_POST['team'], $_POST['user_id']]);
}

if(isset($_POST['update'])){
 $pdo->prepare("UPDATE players SET name=?, team_id=? WHERE id=?")
 ->execute([$_POST['name'], $_POST['team'], $_POST['id']]);
 header("Location: players.php");
 exit();
}

if(isset($_GET['delete'])){
 $pdo->prepare("DELETE FROM players WHERE id=?")->execute([$_GET['delete']]);
 header("Location: players.php");
 exit();
}

$teams = $pdo->query("SELECT * FROM teams")->fetchAll();
$registered_players = $pdo->query("SELECT id, name, email FROM users WHERE role='player' ORDER BY name ASC")->fetchAll();
$players = $pdo->query("
SELECT players.*, teams.name AS team_name 
FROM players 
LEFT JOIN teams ON players.team_id = teams.id
")->fetchAll();
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Players | SportSphere</title>
<link href="https://fonts.googleapis.com/css2?family=Barlow+Condensed:wght@700;900&family=Barlow:wght@400;500;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="organizer_style.css">
</head>
<body>

<div class="sidebar">
  <h2>🏀 SportSphere</h2>
  <a href="dashboard.php">📊 Dashboard</a>
  <a href="tournaments.php">🏆 Tournaments</a>
  <a href="teams.php">👥 Teams</a>
  <a href="matches.php">📅 Matches</a>
  <a href="players.php" class="active">🏀 Players</a>
  <a href="leaderboard.php">🏅 Leaderboard</a>
  <a href="ads.php">📢 Manage Ads</a>
  <a href="auth/logout.php" style="margin-top:20px; color:var(--red);">🚪 Logout</a>
</div>

<div class="main">

<div class="page-header">
  <h1>🏀 Player Roster</h1>
</div>

<form method="POST" class="form-card">
  <div class="grid-2">
    <div>
      <label>Select Registered Player</label>
      <select name="user_id" required>
        <option value="">-- Choose Account --</option>
        <?php foreach($registered_players as $rp): ?>
          <option value="<?= $rp['id'] ?>"><?= htmlspecialchars($rp['name']) ?> (<?= htmlspecialchars($rp['email']) ?>)</option>
        <?php endforeach; ?>
      </select>
    </div>
    <div>
      <label>Assign to Team</label>
      <select name="team" required>
      <?php foreach($teams as $t): ?>
      <option value="<?= $t['id'] ?>"><?= htmlspecialchars($t['name']) ?></option>
      <?php endforeach; ?>
      </select>
    </div>
    <div style="display:flex; align-items:flex-end;">
      <button name="add" class="btn" style="width:100%; margin-bottom:15px;">+ Register Player</button>
    </div>
  </div>
</form>

<h3 style="font-family:'Barlow Condensed', sans-serif; font-size:24px; color:var(--orange); margin-bottom:15px; margin-top:30px;">All Players</h3>

<div class="grid-3">
  <?php foreach($players as $p): ?>
  <div class="card" style="margin-bottom:0;">
    <form method="POST">
      <input type="hidden" name="id" value="<?= $p['id'] ?>">
      <label>Name</label>
      <input name="name" value="<?= htmlspecialchars($p['name']) ?>" required>
      <label>Team</label>
      <select name="team" required>
      <?php foreach($teams as $t): ?>
      <option value="<?= $t['id'] ?>" <?= $p['team_id']==$t['id']?'selected':'' ?>><?= htmlspecialchars($t['name']) ?></option>
      <?php endforeach; ?>
      </select>
      
      <div style="display:flex; gap:10px; margin-top:10px;">
        <button name="update" class="btn btn-sm" style="flex:1;">Save</button>
        <a href="?delete=<?= $p['id'] ?>" class="btn btn-sm btn-red" style="text-align:center; flex:1;" onclick="return confirm('Confirm delete?');">Delete</a>
      </div>
    </form>
  </div>
  <?php endforeach; ?>
</div>

<div style="margin-top:30px;">
  <a href="dashboard.php" class="btn" style="background:#333; color:#fff; padding:10px 20px;">⬅ Back to Dashboard</a>
</div>

</div>
</body>
</html>