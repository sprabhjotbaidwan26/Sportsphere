-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 03, 2026 at 03:52 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sportsphere`
--

-- --------------------------------------------------------

--
-- Table structure for table `ads`
--

CREATE TABLE `ads` (
  `id` int(11) NOT NULL,
  `ad_text` varchar(255) NOT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ads`
--

INSERT INTO `ads` (`id`, `ad_text`, `is_active`, `created_at`) VALUES
(1, 'Sponsor: Nike Basketball Shoes 30% OFF', 1, '2026-04-01 12:56:21'),
(2, 'Join Premium League Now', 1, '2026-04-01 12:56:21'),
(3, 'Live Finals Streaming Tonight 8PM', 1, '2026-04-01 12:56:21');

-- --------------------------------------------------------

--
-- Table structure for table `matches`
--

CREATE TABLE `matches` (
  `id` int(11) NOT NULL,
  `tournament_id` int(11) DEFAULT NULL,
  `team1_id` int(11) DEFAULT NULL,
  `team2_id` int(11) DEFAULT NULL,
  `score1` int(11) DEFAULT 0,
  `score2` int(11) DEFAULT 0,
  `played` tinyint(1) DEFAULT 0,
  `match_date` date DEFAULT NULL,
  `match_time` time DEFAULT NULL,
  `winner` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `matches`
--

INSERT INTO `matches` (`id`, `tournament_id`, `team1_id`, `team2_id`, `score1`, `score2`, `played`, `match_date`, `match_time`, `winner`) VALUES
(1, 1, 1, 2, 5, 2, 1, '2026-04-01', '12:15:00', 1),
(2, 2, 2, 1, 2, 2, 1, '2026-04-06', '01:06:00', 0),
(3, 3, 1, 3, 0, 0, 0, '2026-07-06', '01:58:00', 0),
(4, 4, 1, 2, 0, 0, 0, '2026-04-04', '03:27:00', 0);

-- --------------------------------------------------------

--
-- Table structure for table `players`
--

CREATE TABLE `players` (
  `id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `team_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `players`
--

INSERT INTO `players` (`id`, `name`, `team_id`, `user_id`) VALUES
(1, 'Player 1', 1, NULL),
(2, 'Player 2', 1, 4),
(3, 'Player 11', 2, NULL),
(4, 'Player 12', 2, NULL),
(5, 'Player 21', 3, 4),
(6, 'Player 22', 3, 5),
(7, 'Player24', 3, 6);

-- --------------------------------------------------------

--
-- Table structure for table `teams`
--

CREATE TABLE `teams` (
  `id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `tournament_id` int(11) DEFAULT NULL,
  `points` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `teams`
--

INSERT INTO `teams` (`id`, `name`, `tournament_id`, `points`) VALUES
(1, 'Team A', 1, 4),
(2, 'Team B', 1, 1),
(3, 'Team C', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tournaments`
--

CREATE TABLE `tournaments` (
  `id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `location` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `match_type` enum('round_robin','knockout','league') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tournaments`
--

INSERT INTO `tournaments` (`id`, `name`, `location`, `created_at`, `start_date`, `end_date`, `match_type`) VALUES
(1, 'Inter Academy', 'Vancouver', '2026-03-31 22:14:57', '2026-03-31', '2026-04-01', 'knockout'),
(2, 'State Level', 'Vancouver', '2026-03-31 23:06:47', '2026-04-04', '2026-04-08', 'league'),
(3, 'Swish Fest', 'Tronto', '2026-04-01 23:53:47', '2026-07-01', '2026-07-10', 'league'),
(4, 'T1', 'Surrey, CA', '2026-04-02 01:27:16', '2026-04-04', '2026-04-04', 'round_robin');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `position` varchar(50) DEFAULT NULL,
  `skill` int(11) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `role` enum('player','organizer','spectator') DEFAULT 'player',
  `subscription` varchar(50) DEFAULT 'Basic',
  `reset_token` varchar(255) DEFAULT NULL,
  `token_expiry` datetime DEFAULT NULL,
  `trial_ends_at` datetime DEFAULT NULL,
  `is_paid` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `dob`, `phone`, `position`, `skill`, `address`, `role`, `subscription`, `reset_token`, `token_expiry`, `trial_ends_at`, `is_paid`) VALUES
(1, 'xyz', 'xyz@gmail.com', '$2y$10$.KfzV4c.keFZZ4UpDzJl.epE4VaV73XCwdUc4/tt0zQoCYapO5eNO', '2000-01-01', '', 'PG', 3, '', 'organizer', 'Basic', NULL, NULL, NULL, 0),
(2, 'Kiran', 'Kiran@gmail.com', '$2y$10$ItIVPqca1J0KQ94OBrQAdeDpkDYGvu/M1m16Q0UoExlLk3v6CdhbW', '2000-01-01', '', 'PG', 3, '', 'spectator', 'Basic', NULL, NULL, NULL, 0),
(3, 'abc', 'abc@gmail.com', '$2y$10$Zg18RS5SUVd5lau0m.9pR.gMxhrOJFF9Uv05lD8DFcX8sgbuOe5xa', '2000-01-01', '', 'PG', 3, '', 'player', 'Basic', NULL, NULL, NULL, 0),
(4, 'Player 2', 'Player2@gmail.com', '$2y$10$gPSoze7lkAziZOMN9rN/PuzM.3Xc.Lnn88p3SAkpbvgCmY6StmvTS', '2000-01-01', '', 'PG', 3, '', 'player', 'Player Plan', NULL, NULL, NULL, 0),
(5, 'Player 22', 'Player22@gmail.com', '$2y$10$jHd9TWOFZRTHAwykBW./DOmiFYocWEHivacEZkwAKEe5PUgtKEPbS', '2000-01-01', '', 'PG', 3, '', 'player', 'Player Plan', NULL, NULL, '2026-05-02 01:57:17', 0),
(6, 'Player24', 'Player24@gmail.com', '$2y$10$tT8XPV3TmUJQRbJ8PrqLkOlL99APVTxt8p2KMaZ1bLqjJwFWqSYPO', '2002-02-01', '', 'PG', 2, '', 'player', 'Player Plan', NULL, NULL, '2026-05-02 03:19:25', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ads`
--
ALTER TABLE `ads`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `matches`
--
ALTER TABLE `matches`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `players`
--
ALTER TABLE `players`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `teams`
--
ALTER TABLE `teams`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tournaments`
--
ALTER TABLE `tournaments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `ads`
--
ALTER TABLE `ads`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `matches`
--
ALTER TABLE `matches`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `players`
--
ALTER TABLE `players`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `teams`
--
ALTER TABLE `teams`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tournaments`
--
ALTER TABLE `tournaments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
