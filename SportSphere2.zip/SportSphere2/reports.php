<?php
require "config/db.php";
require "auth_check.php";
require "role_check.php";

allowRoles(['organizer']);

$leaderboard = $pdo->query("
SELECT name, points FROM teams ORDER BY points DESC LIMIT 10
")->fetchAll();

$matches = $pdo->query("
SELECT 
 m.score1, m.score2,
 t1.name AS team1,
 t2.name AS team2
FROM matches m
JOIN teams t1 ON m.team1_id = t1.id
JOIN teams t2 ON m.team2_id = t2.id
WHERE played=1
ORDER BY m.match_date DESC
")->fetchAll();

// Financial Calculations
$playersPaid = $pdo->query("SELECT COUNT(*) FROM users WHERE role='player' AND is_paid=1")->fetchColumn();
$spectatorsPaid = $pdo->query("SELECT COUNT(*) FROM users WHERE role='spectator' AND is_paid=1")->fetchColumn();
$revenuePlayers = $playersPaid * 5;
$revenueSpectators = $spectatorsPaid * 3;
$totalRevenue = $revenuePlayers + $revenueSpectators;
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Reports | SportSphere</title>
<link href="https://fonts.googleapis.com/css2?family=Barlow+Condensed:wght@700;900&family=Barlow:wght@400;500;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="organizer_style.css">
</head>
<body>

<div class="sidebar">
  <h2>🏀 SportSphere</h2>
  <a href="dashboard.php">📊 Dashboard</a>
  <a href="tournaments.php">🏆 Tournaments</a>
  <a href="teams.php">👥 Teams</a>
  <a href="matches.php">📅 Matches</a>
  <a href="players.php">🏀 Players</a>
  <a href="leaderboard.php">🏅 Leaderboard</a>
  <a href="ads.php">📢 Manage Ads</a>
  <a href="auth/logout.php" style="margin-top:20px; color:var(--red);">🚪 Logout</a>
</div>

<div class="main">
  <div class="page-header">
    <h1>📊 Reports & Analytics</h1>
  </div>

  <!-- FINANCIAL REPORT -->
  <div class="card" style="margin-bottom:30px; display:flex; justify-content:space-between; align-items:center; background:linear-gradient(135deg, rgba(82, 237, 137, 0.1), transparent); border:1px solid rgba(82, 237, 137, 0.2);">
    <div>
      <h3 style="margin:0; font-size:22px; font-weight:600; letter-spacing:0.5px; color:var(--green);">Gross Subscription Revenue</h3>
      <p style="margin:5px 0 0 0; color:var(--muted); font-size:14px; font-weight:500;">Earnings from active $5 Player and $3 Spectator subscriptions.</p>
    </div>
    <div style="text-align:right;">
      <div style="font-size:45px; font-family:'Barlow Condensed', sans-serif; font-weight:900; color:var(--green); line-height:1;">$<?= number_format($totalRevenue, 2) ?></div>
      <div style="font-size:13px; color:var(--muted); margin-top:5px; text-transform:uppercase; letter-spacing:1px; font-weight:600;">
        <?= $playersPaid ?> Players | <?= $spectatorsPaid ?> Spectators
      </div>
    </div>
  </div>

  <div class="grid-2">
    <!-- LEADERBOARD SUMMARY -->
    <div class="table-card" style="margin-bottom:30px;">
      <h3 style="padding:20px; margin:0; font-family:'Barlow Condensed', sans-serif; font-size:24px; color:var(--orange); border-bottom:1px solid var(--border);">Top Teams Summary</h3>
      <table>
        <thead>
          <tr>
            <th>Team Name</th>
            <th style="text-align:right;">Points</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach($leaderboard as $t): ?>
          <tr>
            <td style="font-weight:600;"><?= htmlspecialchars($t['name']) ?></td>
            <td style="text-align:right; font-family:'Barlow Condensed', sans-serif; font-size:20px; font-weight:900; color:var(--orange);"><?= $t['points'] ?></td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>

    <!-- MATCH STATS -->
    <div class="table-card" style="margin-bottom:30px;">
      <h3 style="padding:20px; margin:0; font-family:'Barlow Condensed', sans-serif; font-size:24px; color:var(--blue); border-bottom:1px solid var(--border);">Recent Match Results</h3>
      <table>
        <thead>
          <tr>
            <th>Matchup</th>
            <th style="text-align:right;">Final Score</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach($matches as $m): ?>
          <tr>
            <td style="font-size:14px;"><?= htmlspecialchars($m['team1']) ?> <span style="color:var(--muted)">vs</span> <?= htmlspecialchars($m['team2']) ?></td>
            <td style="text-align:right; font-weight:700; font-family:'Barlow Condensed', sans-serif; font-size:18px; color:var(--green);"><?= $m['score1'] ?> - <?= $m['score2'] ?></td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>

  <!-- EXPORT -->
  <div class="card" style="display:flex; justify-content:space-between; align-items:center;">
    <div>
      <h3 style="margin:0; font-size:22px; font-weight:600; letter-spacing:0.5px;">Export Database Reports</h3>
      <p style="margin:5px 0 0 0; color:var(--muted); font-size:14px; font-weight:500;">Download a complete CSV dump of all match data.</p>
    </div>
    <a href="export.php" class="btn" style="background:var(--green); color:#fff; padding:15px 25px; font-size:16px;">📥 Download CSV</a>
  </div>

  <div style="margin-top:30px;">
    <a href="dashboard.php" class="btn" style="background:#333; color:#fff; padding:10px 20px;">⬅ Back to Dashboard</a>
  </div>

</div>

</body>
</html>