<?php
require "config/db.php";
require "auth_check.php";
require "role_check.php";

allowRoles(['organizer']);

// ADD AD
if(isset($_POST['add'])){
 $pdo->prepare("INSERT INTO ads(ad_text, is_active) VALUES(?, 1)")->execute([$_POST['ad_text']]);
}

// TOGGLE AD
if(isset($_GET['toggle'])){
 $id = (int)$_GET['toggle'];
 $pdo->prepare("UPDATE ads SET is_active = NOT is_active WHERE id=?")->execute([$id]);
 header("Location: ads.php");
 exit();
}

// DELETE AD
if(isset($_GET['delete'])){
 $id = (int)$_GET['delete'];
 $pdo->prepare("DELETE FROM ads WHERE id=?")->execute([$id]);
 header("Location: ads.php");
 exit();
}

// FETCH ADS
$ads = $pdo->query("SELECT * FROM ads ORDER BY id DESC")->fetchAll();
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Ads Management | SportSphere</title>
<link href="https://fonts.googleapis.com/css2?family=Barlow+Condensed:wght@700;900&family=Barlow:wght@400;500;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="organizer_style.css">
</head>
<body>

<div class="sidebar">
  <h2>🏀 SportSphere</h2>
  <a href="dashboard.php">📊 Dashboard</a>
  <a href="tournaments.php">🏆 Tournaments</a>
  <a href="teams.php">👥 Teams</a>
  <a href="matches.php">📅 Matches</a>
  <a href="players.php">🏀 Players</a>
  <a href="leaderboard.php">🏅 Leaderboard</a>
  <a href="ads.php" class="active">📢 Manage Ads</a>
  <a href="auth/logout.php" style="margin-top:20px; color:var(--red);">🚪 Logout</a>
</div>

<div class="main">

  <div class="page-header">
    <h1>📢 Advertising Broadcasts</h1>
  </div>

  <form method="POST" class="form-card" style="display:flex; gap:15px; align-items:flex-end;">
    <div style="flex:1;">
      <label>Advertisement Content</label>
      <input name="ad_text" placeholder="e.g. 🔥 Sponsor: Nike Basketball Shoes 30% OFF" required style="margin:0;">
    </div>
    <button name="add" class="btn" style="height:44px; margin:0;">+ Create Broadcast</button>
  </form>

  <div class="table-card">
    <table>
      <thead>
        <tr>
          <th>Ad Content</th>
          <th style="text-align:center;">Status</th>
          <th style="text-align:right;">Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach($ads as $a): ?>
        <tr>
          <td style="font-weight:600; font-size:16px;"><?= htmlspecialchars($a['ad_text']) ?></td>
          <td style="text-align:center;">
            <?php if($a['is_active']): ?>
              <span class="badge badge-active">Running</span>
            <?php else: ?>
              <span class="badge badge-inactive">Paused</span>
            <?php endif; ?>
          </td>
          <td style="text-align:right;">
            <a href="?toggle=<?= $a['id'] ?>" class="btn btn-sm" style="background:#333; color:#fff;">
              <?= $a['is_active'] ? 'Pause' : 'Activate' ?>
            </a>
            <a href="?delete=<?= $a['id'] ?>" class="btn btn-sm btn-red" onclick="return confirm('Delete this ad?');">Delete</a>
          </td>
        </tr>
        <?php endforeach; ?>
        <?php if(count($ads) == 0): ?>
          <tr><td colspan="3" style="text-align:center; color:var(--muted); padding:30px;">No advertisements running.</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>

  <div style="margin-top:30px;">
    <a href="dashboard.php" class="btn" style="background:#333; color:#fff; padding:10px 20px;">⬅ Back to Dashboard</a>
  </div>

</div>

</body>
</html>
