<?php
require "config/db.php";
require "auth_check.php";
require "role_check.php";

allowRoles(['organizer']);

$t = $pdo->query("SELECT COUNT(*) FROM tournaments")->fetchColumn();
$teams = $pdo->query("SELECT COUNT(*) FROM teams")->fetchColumn();
$m = $pdo->query("SELECT COUNT(*) FROM matches")->fetchColumn();
?>

<!DOCTYPE html>
<html>

<head>
  <meta charset="UTF-8">
  <title>Dashboard | SportSphere</title>
  <link
    href="https://fonts.googleapis.com/css2?family=Barlow+Condensed:wght@700;900&family=Barlow:wght@400;500;600&display=swap"
    rel="stylesheet">
  <link rel="stylesheet" href="organizer_style.css">
</head>

<body>

  <div class="sidebar">
    <h2>🏀 SportSphere</h2>
    <a href="dashboard.php" class="active">📊 Dashboard</a>
    <a href="tournaments.php">🏆 Tournaments</a>
    <a href="teams.php">👥 Teams</a>
    <a href="matches.php">📅 Matches</a>
    <a href="players.php">🏀 Players</a>
    <a href="leaderboard.php">🏅 Leaderboard</a>
    <a href="ads.php">📢 Manage Ads</a>
    <a href="auth/logout.php" style="margin-top:20px; color:var(--red);">🚪 Logout</a>
  </div>

  <div class="main">
    <div class="page-header">
      <h1>Organizer Dashboard</h1>
    </div>

    <div class="grid-3">
      <div class="card" style="text-align:center;">
        <h3 style="color:var(--muted); font-size:14px; text-transform:uppercase;">Tournaments</h3>
        <div
          style="font-size:55px; font-family:'Barlow Condensed'; color:var(--orange); font-weight:900; line-height:1;">
          <?= $t ?></div>
      </div>
      <div class="card" style="text-align:center;">
        <h3 style="color:var(--muted); font-size:14px; text-transform:uppercase;">Registered Teams</h3>
        <div
          style="font-size:55px; font-family:'Barlow Condensed'; color:var(--orange); font-weight:900; line-height:1;">
          <?= $teams ?></div>
      </div>
      <div class="card" style="text-align:center;">
        <h3 style="color:var(--muted); font-size:14px; text-transform:uppercase;">Total Matches</h3>
        <div
          style="font-size:55px; font-family:'Barlow Condensed'; color:var(--orange); font-weight:900; line-height:1;">
          <?= $m ?></div>
      </div>
    </div>

    <h3 style="color:var(--orange); font-family:'Barlow Condensed'; font-size:24px; margin-top:10px;">Quick Management
    </h3>

    <div class="grid-4" style="margin-top:15px;">
      <a href="tournaments.php" class="card"
        style="text-align:center; text-decoration:none; display:block; transition:0.3s; padding:30px;">
        <div style="font-size:36px; margin-bottom:10px;">🏆</div>
        <h3 style="margin:0; font-size:18px;">Tournaments</h3>
      </a>
      <a href="teams.php" class="card"
        style="text-align:center; text-decoration:none; display:block; transition:0.3s; padding:30px;">
        <div style="font-size:36px; margin-bottom:10px;">👥</div>
        <h3 style="margin:0; font-size:18px;">Teams & Players</h3>
      </a>
      <a href="matches.php" class="card"
        style="text-align:center; text-decoration:none; display:block; transition:0.3s; padding:30px;">
        <div style="font-size:36px; margin-bottom:10px;">📅</div>
        <h3 style="margin:0; font-size:18px;">Match Schedule</h3>
      </a>
      <a href="leaderboard.php" class="card"
        style="text-align:center; text-decoration:none; display:block; transition:0.3s; padding:30px;">
        <div style="font-size:36px; margin-bottom:10px;">🏅</div>
        <h3 style="margin:0; font-size:18px;">Leaderboards</h3>
      </a>
    </div>

    <div class="grid-4">
      <a href="reports.php" class="card"
        style="text-align:center; text-decoration:none; display:block; transition:0.3s; padding:30px;">
        <div style="font-size:36px; margin-bottom:10px;">📊</div>
        <h3 style="margin:0; font-size:18px;">Reports</h3>
      </a>
      <a href="ads.php" class="card"
        style="text-align:center; text-decoration:none; display:block; transition:0.3s; padding:30px;">
        <div style="font-size:36px; margin-bottom:10px;">📢</div>
        <h3 style="margin:0; font-size:18px;">Ad Broadcasts</h3>
      </a>
    </div>

  </div>
</body>

</html>