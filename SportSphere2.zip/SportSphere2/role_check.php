<?php
function allowRoles($roles){
 if(!isset($_SESSION['role']) || !in_array($_SESSION['role'], $roles)){
  echo "<h2 style='color:red; text-align:center;'>Access Denied</h2>";
  exit();
 }
}
?>