<?php
require "config/db.php";
require "auth_check.php";
require "role_check.php";

allowRoles(['organizer']);

// ADD TOURNAMENT
if (isset($_POST['add'])) {
  $pdo->prepare("
 INSERT INTO tournaments(name,start_date,end_date,location,match_type)
 VALUES(?,?,?,?,?)
 ")->execute([
        $_POST['name'],
        $_POST['start_date'],
        $_POST['end_date'],
        $_POST['location'],
        $_POST['match_type']
      ]);
}

// FETCH TOURNAMENTS
$tours = $pdo->query("SELECT * FROM tournaments ORDER BY id DESC")->fetchAll();
?>

<!DOCTYPE html>
<html>

<head>
  <meta charset="UTF-8">
  <title>Tournaments | SportSphere</title>
  <link
    href="https://fonts.googleapis.com/css2?family=Barlow+Condensed:wght@700;900&family=Barlow:wght@400;500;600&display=swap"
    rel="stylesheet">
  <link rel="stylesheet" href="organizer_style.css">
</head>

<body>

  <div class="sidebar">
    <h2>🏀 SportSphere</h2>
    <a href="dashboard.php">📊 Dashboard</a>
    <a href="tournaments.php" class="active">🏆 Tournaments</a>
    <a href="teams.php">👥 Teams</a>
    <a href="matches.php">📅 Matches</a>
    <a href="players.php">🏀 Players</a>
    <a href="leaderboard.php">🏅 Leaderboard</a>
    <a href="ads.php">📢 Manage Ads</a>
    <a href="auth/logout.php" style="margin-top:20px; color:var(--red);">🚪 Logout</a>
  </div>

  <div class="main">
    <div class="page-header">
      <h1>🏆 Tournaments</h1>
    </div>

    <form method="POST" class="form-card">
      <div class="grid-2">
        <div><label>Tournament Name</label><input name="name" placeholder="e.g. Summer League 2026" required></div>
        <div><label>Location</label><input name="location" placeholder="e.g. Municipal Arena" required></div>
        <div><label>Start Date</label><input type="date" name="start_date" required></div>
        <div><label>End Date</label><input type="date" name="end_date" required></div>
        <div>
          <label>Match Type format</label>
          <select name="match_type" required>
            <option value="round_robin">Round Robin</option>
            <option value="knockout">Knockout</option>
            <option value="league">League</option>
          </select>
        </div>
        <div style="display:flex; align-items:flex-end;">
          <button name="add" class="btn" style="width:100%; margin-bottom:15px;">+ Create Tournament</button>
        </div>
      </div>
    </form>

    <div class="grid-3">
      <?php foreach ($tours as $t): ?>
        <div class="card" style="margin-bottom:0;">
          <h3 style="font-size:24px; font-family:'Barlow Condensed', sans-serif; letter-spacing:1px; margin-bottom:10px;">
            <?= htmlspecialchars($t['name']) ?></h3>

          <div style="font-size:14px; color:var(--muted); margin-bottom:5px; font-weight:500;">📅
            <?= date("M d, Y", strtotime($t['start_date'])) ?> → <?= date("M d, Y", strtotime($t['end_date'])) ?></div>
          <div style="font-size:14px; color:var(--muted); font-weight:500;">📍 <?= htmlspecialchars($t['location']) ?>
          </div>

          <div style="margin-top:20px;">
            <span class="badge badge-orange"><?= ucfirst(str_replace('_', ' ', $t['match_type'])) ?></span>
          </div>
        </div>
      <?php endforeach; ?>
    </div>

    <div style="margin-top:30px;">
      <a href="dashboard.php" class="btn" style="background:#333; color:#fff; padding:10px 20px;">⬅ Back to Dashboard</a>
    </div>

  </div>

</body>

</html>