<?php
require "config/db.php";
require "auth_check.php";
require "role_check.php";

allowRoles(['organizer']);

// ADD TEAM
if(isset($_POST['add_team'])){
 $pdo->prepare("INSERT INTO teams(name,tournament_id) VALUES(?,?)")
 ->execute([$_POST['name'], 1]);

 $team_id = $pdo->lastInsertId();

 if(!empty($_POST['user_id'])){
  $n = $pdo->query("SELECT name FROM users WHERE id=".(int)$_POST['user_id'])->fetchColumn();
  $pdo->prepare("INSERT INTO players(name,team_id,user_id) VALUES(?,?,?)")
  ->execute([$n, $team_id, $_POST['user_id']]);
 }
}

// ADD PLAYER
if(isset($_POST['add_player'])){
 $n = $pdo->query("SELECT name FROM users WHERE id=".(int)$_POST['user_id'])->fetchColumn();
 $pdo->prepare("INSERT INTO players(name,team_id,user_id) VALUES(?,?,?)")
 ->execute([$n, $_POST['team_id'], $_POST['user_id']]);
}

// UPDATE PLAYER
if(isset($_POST['update_player'])){
 $pdo->prepare("UPDATE players SET name=? WHERE id=?")
 ->execute([$_POST['player_name'], $_POST['player_id']]);
}

// DELETE PLAYER
if(isset($_GET['delete_player'])){
 $pdo->prepare("DELETE FROM players WHERE id=?")
 ->execute([$_GET['delete_player']]);
 header("Location: teams.php");
 exit();
}

// UPDATE TEAM
if(isset($_POST['update_team'])){
 $pdo->prepare("UPDATE teams SET name=? WHERE id=?")
 ->execute([$_POST['team_name'], $_POST['team_id']]);
}

// FETCH TEAMS & PLAYERS
$teams = $pdo->query("SELECT * FROM teams")->fetchAll();
$registered_players = $pdo->query("SELECT id, name, email FROM users WHERE role='player' ORDER BY name ASC")->fetchAll();
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Teams | SportSphere</title>
<link href="https://fonts.googleapis.com/css2?family=Barlow+Condensed:wght@700;900&family=Barlow:wght@400;500;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="organizer_style.css">
</head>
<body>

<div class="sidebar">
  <h2>🏀 SportSphere</h2>
  <a href="dashboard.php">📊 Dashboard</a>
  <a href="tournaments.php">🏆 Tournaments</a>
  <a href="teams.php" class="active">👥 Teams</a>
  <a href="matches.php">📅 Matches</a>
  <a href="players.php">🏀 Players</a>
  <a href="leaderboard.php">🏅 Leaderboard</a>
  <a href="ads.php">📢 Manage Ads</a>
  <a href="auth/logout.php" style="margin-top:20px; color:var(--red);">🚪 Logout</a>
</div>

<div class="main">
  <div class="page-header">
    <h1>👥 Team Management</h1>
  </div>

  <form method="POST" class="form-card">
    <div class="grid-2">
      <div><label>Team Name</label><input name="name" placeholder="e.g. Phoenix Suns" required></div>
      <div>
        <label>Assign First Player (Optional)</label>
        <select name="user_id">
          <option value="">-- Leave Empty --</option>
          <?php foreach($registered_players as $rp): ?>
            <option value="<?= $rp['id'] ?>"><?= htmlspecialchars($rp['name']) ?> (<?= htmlspecialchars($rp['email']) ?>)</option>
          <?php endforeach; ?>
        </select>
      </div>
    </div>
    <button name="add_team" class="btn">+ Create Team</button>
  </form>

  <div class="grid-2">
    <?php foreach($teams as $t): ?>
    <div class="card" style="margin-bottom:0;">
      
      <form method="POST" style="display:flex; gap:10px; margin-bottom:20px;">
        <input type="hidden" name="team_id" value="<?= $t['id'] ?>">
        <input name="team_name" value="<?= htmlspecialchars($t['name']) ?>" style="margin:0; font-size:24px; font-weight:900; font-family:'Barlow Condensed', sans-serif;">
        <button name="update_team" class="btn btn-sm" style="margin:0;">Rename</button>
      </form>

      <?php $players = $pdo->query("SELECT * FROM players WHERE team_id=".$t['id'])->fetchAll(); ?>
      
      <?php if(count($players) > 0): ?>
        <h4 style="color:var(--muted); text-transform:uppercase; font-size:12px; margin-bottom:10px;">Roster</h4>
      <?php endif; ?>

      <?php foreach($players as $p): ?>
        <form method="POST" style="display:flex; gap:5px; align-items:center; margin-bottom:8px;">
          <input type="hidden" name="player_id" value="<?= $p['id'] ?>">
          <input name="player_name" value="<?= htmlspecialchars($p['name']) ?>" style="margin:0; padding:8px 10px;">
          <button name="update_player" class="btn btn-sm" style="margin:0; padding:9px 12px;">Edit</button>
          
          <a class="btn btn-sm btn-red" href="?delete_player=<?= $p['id'] ?>" style="margin:0; padding:8px 12px;" onclick="return confirm('Confirm delete?');">Delete</a>
        </form>
      <?php endforeach; ?>

      <form method="POST" style="display:flex; gap:10px; margin-top:20px; border-top:1px solid var(--border); padding-top:15px;">
        <input type="hidden" name="team_id" value="<?= $t['id'] ?>">
        <select name="user_id" required style="margin:0;">
          <option value="">Select a registered player...</option>
          <?php foreach($registered_players as $rp): ?>
            <option value="<?= $rp['id'] ?>"><?= htmlspecialchars($rp['name']) ?> (<?= htmlspecialchars($rp['email']) ?>)</option>
          <?php endforeach; ?>
        </select>
        <button name="add_player" class="btn btn-sm" style="margin:0; padding:10px 20px;">+ Add Team Member</button>
      </form>

    </div>
    <?php endforeach; ?>
  </div>

  <div style="margin-top:30px;">
    <a href="dashboard.php" class="btn" style="background:#333; color:#fff; padding:10px 20px;">⬅ Back to Dashboard</a>
  </div>

</div>

</body>
</html>
