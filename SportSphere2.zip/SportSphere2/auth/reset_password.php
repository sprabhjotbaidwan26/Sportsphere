<?php
require "../config/db.php";

$token = $_GET['token'] ?? '';
$msg = "";

// CHECK TOKEN
$stmt = $pdo->prepare("SELECT * FROM users WHERE reset_token=?");
$stmt->execute([$token]);
$user = $stmt->fetch();

if(!$user){
 die("Invalid token!");
}

// CHECK EXPIRY
if(strtotime($user['token_expiry']) < time()){
 die("Token expired!");
}

// RESET PASSWORD
if(isset($_POST['reset'])){
 $pass = password_hash($_POST['password'], PASSWORD_DEFAULT);

 $pdo->prepare("UPDATE users SET password=?, reset_token=NULL, token_expiry=NULL WHERE id=?")
     ->execute([$pass, $user['id']]);

 header("Location: login.php");
 exit();
}
?>

<link rel="stylesheet" href="../style.css">

<div class="container">
<h2>Reset Password</h2>

<form method="POST">
<input type="password" name="password" placeholder="New Password" required>
<button name="reset">Reset Password</button>
</form>
</div>