<?php
session_start();

// destroy all session data
$_SESSION = [];
session_unset();
session_destroy();

// prevent back button caching
header("Cache-Control: no-cache, no-store, must-revalidate");
header("Pragma: no-cache");
header("Expires: 0");

// redirect to login
header("Location: login.php");
exit();