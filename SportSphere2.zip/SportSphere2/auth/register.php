<?php

require "../config/db.php";
if(session_status() === PHP_SESSION_NONE){
 session_start();
}

$error = "";

if($_POST){

 $name = $_POST['name'];
 $email = $_POST['email'];
 $role = $_POST['role'];
 $pass = password_hash($_POST['password'], PASSWORD_DEFAULT);

 // ✅ SAFE OPTIONAL FIELDS
 $dob = $_POST['dob'] ?? null;
 $phone = $_POST['phone'] ?? null;
 $position = $_POST['position'] ?? null;
 $skill = $_POST['skill'] ?? 1;
 $address = $_POST['address'] ?? null;

 // ❗ CHECK DUPLICATE EMAIL
 $check = $pdo->prepare("SELECT id FROM users WHERE email=?");
 $check->execute([$email]);

 if($check->fetch()){
  $error = "Email already registered!";
 } else {

  // 🎯 ASSIGN SUBSCRIPTION
  if($role == 'player'){
   $subscription = 'Player Plan';
  } elseif($role == 'spectator'){
   $subscription = 'Viewer Plan';
  } else {
   $subscription = 'Free';
  }

  try {

   $trial_ends_at = date('Y-m-d H:i:s', strtotime('+30 days'));
   
   // 🔥 SAFE INSERT (MATCHES DB)
   $stmt = $pdo->prepare("
   INSERT INTO users(name,email,password,dob,phone,position,skill,address,role,subscription,trial_ends_at,is_paid)
   VALUES(?,?,?,?,?,?,?,?,?,?,?,?)
   ");

   $stmt->execute([
    $name,
    $email,
    $pass,
    $dob,
    $phone,
    $position,
    $skill,
    $address,
    $role,
    $subscription,
    $trial_ends_at,
    0
   ]);

   header("Location: login.php?registered=1");
   exit();

  } catch (PDOException $e){
   $error = "Error: " . $e->getMessage();
  }
 }
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Register</title>
<link rel="stylesheet" href="../style.css">
</head>

<body class="auth-page">

<div class="card register-card">
<h2>Register</h2>

<!-- 🔥 ERROR DISPLAY -->
<?php if($error): ?>
<p style="color:red; text-align:center;"><?= $error ?></p>
<?php endif; ?>

<form method="POST">

<input name="name" placeholder="Full Name" required>
<input type="email" name="email" placeholder="Email" required>
<input type="password" name="password" placeholder="Password" required>

<label>Date of Birth</label>
<input type="date" name="dob" required>

<label>Phone</label>
<input name="phone" placeholder="Phone">

<select name="position">
<option>PG</option>
<option>SG</option>
<option>SF</option>
<option>PF</option>
<option>C</option>
</select>

<label>Skill (1-5)</label>
<input type="range" name="skill" min="1" max="5">

<label>Register As</label>
<select name="role" required>
<option value="player">Player</option>
<option value="organizer">Organizer</option>
<option value="spectator">Spectator</option>
</select>

<p style="font-size:13px; color:#FF5C1A; font-weight:600; margin-top:5px;">
🎉 30-Day Free Trial For All New Users!
</p>
<p style="font-size:12px; color:#aaa; margin-top:0;">
After your free trial ends, you will be prompted to cover the monthly fee based on your role:<br>
<strong>Player → $5/month | Spectator → $3/month | Organizer → Free</strong>
</p>

<label>Address</label>
<textarea name="address" placeholder="Address"></textarea>

<button type="submit">Register</button>

<a href="login.php">
<button type="button" class="back-btn">⬅ Back</button>
</a>

</form>
</div>

</body>
</html>