<?php
require "../config/db.php";
$error = "";
$success_msg = isset($_GET['registered']) ? "Registration successful! Log in to start your 30-day free trial." : "";

// Handle POST request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email']);
    $password = $_POST['password'];

    // Fetch user by email
    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user && password_verify($password, $user['password'])) {
        // Store user info in session
        $_SESSION['user'] = $user['id'];
        $_SESSION['role'] = strtolower($user['role']);
        $_SESSION['trial_ends_at'] = $user['trial_ends_at'];
        $_SESSION['is_paid'] = $user['is_paid'];
        $_SESSION['subscription'] = $user['subscription'];

        // Redirect based on role
        switch ($_SESSION['role']) {
            case 'organizer':
                header("Location: ../dashboard.php");
                exit;
            case 'player':
                header("Location: ../playerdashboard.php");
                exit;
            case 'spectator':
                header("Location: ../spectatordashboard.php");
                exit;
            default:
                $error = "Role not recognized. Contact admin.";
        }
    } else {
        $error = "Invalid email or password";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>SportSphere Login</title>
<link href="https://fonts.googleapis.com/css2?family=Barlow:wght@400;500;600&family=Barlow+Condensed:wght@700;900&display=swap" rel="stylesheet">
<style>
body{
    margin:0;
    font-family:'Barlow', sans-serif;
    background: linear-gradient(135deg, #0F0F0F, #1A1A1A);
    display:flex;
    justify-content:center;
    align-items:center;
    height:100vh;
    color:#F5F5F5;
}
.auth-card{
    background:#1A1A1A;
    padding:40px;
    border-radius:12px;
    width:100%;
    max-width:400px;
    box-shadow:0 5px 20px rgba(0,0,0,0.5);
    text-align:center;
}
.auth-card h2{
    font-family:'Barlow Condensed',sans-serif;
    color:#FF5C1A;
    margin-bottom:25px;
}
.auth-card input{
    width:100%;
    padding:12px 15px;
    margin:10px 0;
    border:none;
    border-radius:6px;
    background:#111;
    color:#F5F5F5;
    font-size:16px;
}
.auth-card button{
    width:100%;
    padding:12px;
    margin-top:15px;
    border:none;
    border-radius:6px;
    background:#FF5C1A;
    color:#fff;
    font-size:16px;
    font-weight:700;
    cursor:pointer;
    transition:0.3s;
}
.auth-card button:hover{
    background:#cc4200;
}
.auth-card .error{
    background:#FF4D4D;
    padding:10px;
    border-radius:6px;
    margin-bottom:15px;
}
.auth-card a{
    color:#FF5C1A;
    text-decoration:none;
}
.auth-card a:hover{
    text-decoration:underline;
}
</style>
</head>
<body>

<div class="auth-card">
<h2>SportSphere Login</h2>

<?php if($error): ?>
    <div class="error"><?= htmlspecialchars($error) ?></div>
<?php endif; ?>

<?php if($success_msg): ?>
    <div style="background:#4CAF50; padding:10px; border-radius:6px; margin-bottom:15px; color:#fff;">
        <?= htmlspecialchars($success_msg) ?>
    </div>
<?php endif; ?>

<form method="POST">
    <input type="email" name="email" placeholder="Email" required>
    <input type="password" name="password" placeholder="Password" required>
    <button type="submit">Login</button>
</form>

<p>Don't have an account? <a href="register.php">Register</a></p>
<p><a href="forgot_password.php">Forgot Password</a></p>

</div>

</body>
</html>