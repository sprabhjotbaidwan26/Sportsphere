<?php
require "../config/db.php";

$msg = "";

if(isset($_POST['check_email'])){
 $email = $_POST['email'];

 $stmt = $pdo->prepare("SELECT id FROM users WHERE email=?");
 $stmt->execute([$email]);

 if($stmt->rowCount() > 0){

  // 🔐 GENERATE TOKEN
  $token = bin2hex(random_bytes(32));

  // ⏳ EXPIRY (30 minutes)
  $expiry = date("Y-m-d H:i:s", strtotime("+30 minutes"));

  // SAVE TOKEN
  $pdo->prepare("UPDATE users SET reset_token=?, token_expiry=? WHERE email=?")
      ->execute([$token, $expiry, $email]);

  // 🔗 RESET LINK
  $link = "http://localhost/Sportsphere/auth/reset_password.php?token=$token";

  $msg = "Reset link (copy & open): <br><a href='$link'>$link</a>";

 } else {
  $msg = "Email not found!";
 }
}
?>

<link rel="stylesheet" href="../style.css">

<div class="container">
<h2>Forgot Password</h2>

<form method="POST">
<input type="email" name="email" placeholder="Enter your email" required>
<button name="check_email">Send Reset Link</button>
</form>

<p><?= $msg ?></p>

<a href="login.php">⬅ Back to Login</a>
</div>