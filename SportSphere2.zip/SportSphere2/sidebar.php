<div class="sidebar">
<h3 style="color:#FF5C1A; text-align:center;">SportSphere</h3>

<a href="dashboard.php">Dashboard</a>

<?php if(isset($_SESSION['role']) && $_SESSION['role']=='organizer'): ?>
<a href="tournaments.php">Tournaments</a>
<a href="teams.php">Teams</a>
<a href="matches.php">Matches</a>
<?php endif; ?>

<a href="leaderboard.php">Leaderboard</a>

<a href="auth/logout.php">Logout</a>
</div>